package com.milichrome.browser

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import android.net.Uri
import com.milichrome.browser.core.browser.BrowserEngine
import com.milichrome.browser.core.tabs.BrowserTab
import org.mozilla.geckoview.GeckoSession
import org.mozilla.geckoview.GeckoView

class MainActivity : Activity() {
    private val black = Color.rgb(15, 15, 17)
    private val panel = Color.rgb(34, 34, 38)
    private val red = Color.rgb(220, 30, 42)
    private val white = Color.WHITE
    private lateinit var engine: BrowserEngine
    private lateinit var host: FrameLayout
    private lateinit var address: EditText
    private lateinit var tabCount: TextView
    private var geckoView: GeckoView? = null
    private val tabs = mutableListOf<BrowserTab>()
    private var active = -1
    private val prefs by lazy { getSharedPreferences("mili_chrome_v2", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        engine = BrowserEngine(this)
        buildUi()
        val start = prefs.getString("home", "https://www.google.com") ?: "https://www.google.com"
        tabs += BrowserTab(url = start, title = "صفحه اصلی")
        activateTab(0)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun textButton(value: String, action: () -> Unit) = TextView(this).apply {
        text = value; textSize = 20f; gravity = Gravity.CENTER; setTextColor(white)
        setOnClickListener { action() }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(black) }
        host = FrameLayout(this).apply { setBackgroundColor(Color.WHITE) }
        root.addView(host, LinearLayout.LayoutParams(-1, 0, 1f))

        val bottom = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(black); setPadding(dp(7), dp(5), dp(7), dp(5)) }
        val addressRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        address = EditText(this).apply {
            hint = "جستجو یا نشانی وب"; setSingleLine(true); textSize = 14f
            setTextColor(white); setHintTextColor(Color.LTGRAY); setPadding(dp(12), 0, dp(8), 0)
            setBackgroundColor(panel); imeOptions = EditorInfo.IME_ACTION_GO
            setOnEditorActionListener { _, action, _ ->
                if (action == EditorInfo.IME_ACTION_GO) { navigate(text.toString()); clearFocus(); true } else false
            }
        }
        addressRow.addView(address, LinearLayout.LayoutParams(0, dp(44), 1f))
        addressRow.addView(textButton("↻") { currentSession()?.reload() }, LinearLayout.LayoutParams(dp(42), dp(44)))
        bottom.addView(addressRow)

        val tools = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(0, dp(3), 0, 0) }
        tools.addView(textButton("‹") { currentSession()?.goBack() }, LinearLayout.LayoutParams(0, dp(44), 1f))
        tools.addView(textButton("›") { currentSession()?.goForward() }, LinearLayout.LayoutParams(0, dp(44), 1f))
        tools.addView(textButton("⌂") { navigate(prefs.getString("home", "https://www.google.com") ?: "https://www.google.com") }, LinearLayout.LayoutParams(0, dp(44), 1f))
        tools.addView(textButton("＋") { addTab(true) }, LinearLayout.LayoutParams(0, dp(44), 1f))
        tabCount = textButton("1") { showTabs() }
        tools.addView(tabCount, LinearLayout.LayoutParams(0, dp(44), 1f))
        tools.addView(textButton("⋮") { showMenu() }, LinearLayout.LayoutParams(0, dp(44), 1f))
        bottom.addView(tools)
        root.addView(bottom)
        setContentView(root)
        window.statusBarColor = black
        window.navigationBarColor = black
    }

    private fun currentTab() = tabs.getOrNull(active)
    private fun currentSession() = currentTab()?.session

    private fun normalize(raw: String): String {
        val value = raw.trim()
        if (value.isEmpty()) return "about:blank"
        if (value.startsWith("http://") || value.startsWith("https://") || value.startsWith("about:")) return value
        return if (value.contains('.') && !value.contains(' ')) "https://$value"
        else "https://www.google.com/search?q=${Uri.encode(value)}"
    }

    private fun navigate(raw: String) {
        val tab = currentTab() ?: return
        val url = normalize(raw)
        tab.url = url
        tab.hasStartedLoading = true
        address.setText(url)
        val session = ensureSession(tab)
        session.loadUri(url)
    }

    private fun ensureSession(tab: BrowserTab): GeckoSession {
        val existing = tab.session
        if (existing != null) return existing
        val created = engine.createSession(tab.isPrivate)
        created.setNavigationDelegate(object : GeckoSession.NavigationDelegate {
            override fun onLocationChange(
                session: GeckoSession,
                url: String?,
                perms: MutableList<GeckoSession.PermissionDelegate.ContentPermission>,
                hasUserGesture: Boolean
            ) {
                if (currentTab()?.session === session && !url.isNullOrBlank()) {
                    currentTab()?.url = url
                    address.setText(url)
                }
            }
        })
        tab.session = created
        return created
    }

    private fun activateTab(index: Int) {
        if (index !in tabs.indices) return
        currentSession()?.setActive(false)
        geckoView?.let { it.releaseSession() }
        active = index
        val tab = tabs[index]
        val session = ensureSession(tab)
        val newView = GeckoView(this)
        newView.setSession(session)
        geckoView = newView
        host.removeAllViews()
        host.addView(newView, FrameLayout.LayoutParams(-1, -1))
        session.setActive(true)
        if (!tab.hasStartedLoading && tab.url != "about:blank") {
            tab.hasStartedLoading = true
            session.loadUri(tab.url)
        }
        address.setText(if (tab.url == "about:blank") "" else tab.url)
        updateTabCount()
    }

    private fun addTab(activateNow: Boolean, url: String = "about:blank") {
        tabs += BrowserTab(url = url)
        if (activateNow) activateTab(tabs.lastIndex) else updateTabCount()
    }

    private fun updateTabCount() { if (::tabCount.isInitialized) tabCount.text = tabs.size.toString() }

    private fun showTabs() {
        val labels = tabs.mapIndexed { i, t -> "${if (i == active) "● " else ""}${t.title}  ${t.url}" }.toTypedArray()
        AlertDialog.Builder(this).setTitle("تب‌ها")
            .setItems(labels) { _, which -> activateTab(which) }
            .setPositiveButton("تب جدید") { _, _ -> addTab(true) }
            .setNegativeButton("بستن تب فعلی") { _, _ -> closeTab() }.show()
    }

    private fun closeTab() {
        if (tabs.isEmpty()) return
        tabs.removeAt(active).session?.close()
        if (tabs.isEmpty()) tabs += BrowserTab()
        val next = active.coerceAtMost(tabs.lastIndex)
        activateTab(next)
    }

    private fun showMenu() {
        val items = arrayOf("تنظیمات", "خانه", "نشانک این صفحه", "حالت خصوصی", "تلگرام داخلی (در حال توسعه)")
        AlertDialog.Builder(this).setTitle("Mili Chrome").setItems(items) { _, which ->
            when (which) {
                0 -> showSettings()
                1 -> navigate(prefs.getString("home", "https://www.google.com") ?: "https://www.google.com")
                2 -> Toast.makeText(this, "مدیریت نشانک در مرحله بعد متصل می‌شود", Toast.LENGTH_SHORT).show()
                3 -> Toast.makeText(this, "حالت خصوصی پس از تکمیل جداسازی ذخیره‌سازی فعال می‌شود", Toast.LENGTH_LONG).show()
                4 -> Toast.makeText(this, "اتصال امن TDLib در مرحله تلگرام پیاده‌سازی می‌شود", Toast.LENGTH_LONG).show()
            }
        }.show()
    }

    private fun showSettings() {
        val items = arrayOf("کیفیت اصلی", "کیفیت اصلی مات", "بدون عکس", "تنظیمات Mili Shield", "مدیریت پاپ‌آپ‌ها", "محل نوار ابزار: پایین")
        val current = prefs.getInt("image_mode", 0).coerceIn(0, 2)
        AlertDialog.Builder(this).setTitle("تنظیمات Mili Chrome")
            .setSingleChoiceItems(items, current) { dialog, which ->
                if (which <= 2) {
                    prefs.edit().putInt("image_mode", which).apply()
                    Toast.makeText(this, "حالت تصویر ذخیره شد؛ اتصال فیلتر تصویر در مرحله بعد تکمیل می‌شود", Toast.LENGTH_LONG).show()
                    dialog.dismiss()
                } else {
                    Toast.makeText(this, "این بخش در مرحله بعد به موتور مرورگر متصل می‌شود", Toast.LENGTH_SHORT).show()
                    dialog.dismiss()
                }
            }.setNegativeButton("بستن", null).show()
    }

    override fun onPause() {
        currentSession()?.setActive(false)
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        currentSession()?.setActive(true)
    }

    override fun onDestroy() {
        tabs.forEach { it.session?.close() }
        super.onDestroy()
    }
}
