# Mili Chrome — معماری جدید GeckoView

این نسخه، مرحله مهاجرت موتور از Android System WebView به GeckoView است؛ هنوز نسخه نهایی مرورگر نیست.

## چرا موتور عوض شد؟
- WebView سیستمی برای ساخت مرورگر کامل طراحی نشده و نسخه موتور به دستگاه وابسته است.
- GeckoView موتور مستقل Gecko را درون برنامه قرار می‌دهد و API مناسب‌تری برای ساخت مرورگر و اجرای WebExtension دارد.
- مستندات رسمی: https://mozilla.github.io/geckoview/ و https://firefox-source-docs.mozilla.org/mobile/android/geckoview/consumer/web-extensions.html

## پایه فنی این نسخه
- GeckoView Stable: `161.0.20261118180411`
- Android minSdk 26، Java 17، Gradle 8.9، AGP 8.7.3
- ABI فعلی: `arm64-v8a` برای گوشی هدف کاربر؛ این باعث می‌شود APK برای دستگاه‌های ۳۲بیتی مناسب نباشد.
- تب جدید به‌صورت رکورد URL ساخته می‌شود و GeckoSession فقط هنگام فعال‌سازی تب ساخته می‌شود.
- نوار آدرس و ابزارها پایین صفحه قرار دارند.
- سورس قبلی WebView در `com/linkpilot/browser/LegacyMainActivity.kt` فقط برای مرجع مهاجرت حفظ شده و Activity اصلی نیست.

## معماری هدف
- `core/browser`: مدیریت GeckoRuntime و GeckoSession
- `core/tabs`: مدل و چرخه عمر تب‌ها
- `core/privacy`: تنظیمات محافظت مجزا برای هر سایت
- `feature/telegram`: قرارداد کلاینت TDLib؛ اتصال واقعی TDLib هنوز انجام نشده
- `feature/images`: سه حالت تصویر مورد توافق
- `feature/popups`: سیاست تصمیم‌گیری پاپ‌آپ
- `assets/extensions/mili-shield`: محل افزونه محافظتی WebExtension

## مواردی که هنوز پیاده‌سازی نشده‌اند
این نسخه پایه مهاجرت موتور است و نباید به‌عنوان مرورگر کامل یا آماده انتشار معرفی شود:
- اتصال واقعی Mili Shield به GeckoView و افزونه فیلتر تبلیغات
- مدیریت واقعی پاپ‌آپ و مسدودسازی عنصر با لمس طولانی
- اعمال واقعی حالت‌های تصویر؛ در حال حاضر فقط انتخاب ذخیره می‌شود
- ورود و ارسال پیام واقعی Telegram با TDLib
- ترجمه شناور، Reader Mode، Playlist، Sync، Password Manager
- VPN، Tor، Wallet، Rewards و سرویس‌های ابری؛ این‌ها نیازمند زیرساخت و بررسی امنیت/مجوز جدا هستند

## ساخت APK
GitHub Actions از مسیر `.github/workflows/android.yml` فایل APK را می‌سازد. اولین build باید در Actions انجام شود تا دریافت GeckoView از مخزن رسمی Mozilla و سازگاری Gradle بررسی شود. در محیط آماده‌سازی حاضر Android SDK و اتصال شبکه Gradle موجود نبود؛ بنابراین build کامل ادعا نمی‌شود.
