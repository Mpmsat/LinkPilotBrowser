plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.milichrome.browser"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.milichrome.browser"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "0.2.0-gecko-foundation"
        ndk { abiFilters += listOf("arm64-v8a") }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    packaging {
        jniLibs { useLegacyPackaging = true }
        resources { excludes += setOf("META-INF/LICENSE*", "META-INF/NOTICE*") }
    }
}

dependencies {
    // Bundled Firefox/Gecko engine for a consistent browser runtime.
    implementation("org.mozilla.geckoview:geckoview-arm64-v8a:161.0.20261118180411")
}
