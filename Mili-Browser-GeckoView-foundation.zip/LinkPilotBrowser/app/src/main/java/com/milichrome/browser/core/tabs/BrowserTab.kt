package com.milichrome.browser.core.tabs

import org.mozilla.geckoview.GeckoSession
import java.util.UUID

data class BrowserTab(
    val id: String = UUID.randomUUID().toString(),
    var url: String = "about:blank",
    var title: String = "تب جدید",
    var isPrivate: Boolean = false,
    var session: GeckoSession? = null,
    var hasStartedLoading: Boolean = false
)
