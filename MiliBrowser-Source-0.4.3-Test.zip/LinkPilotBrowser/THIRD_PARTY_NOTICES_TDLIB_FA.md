# اطلاعیه مجوزهای کتابخانه‌های شخص ثالث

## TDLib

TDLib تحت مجوز Boost Software License 1.0 منتشر شده است. باینری‌ها و Java bindings مورد استفاده در این پروژه از بسته TDLib v1.8.67 منتشرشده توسط CodexofLost/tdlib-packed دریافت می‌شوند؛ منشأ اعلام‌شده آن TGX-Android/tdlib و TDLib upstream است.

متن مجوز: https://www.boost.org/LICENSE_1_0.txt

## GeckoView

موتور GeckoView تحت Mozilla Public License 2.0 منتشر می‌شود.

متن مجوز: https://www.mozilla.org/MPL/2.0/

## فهرست‌های فیلتر

EasyList و EasyPrivacy در زمان اجرا از میزبان رسمی EasyList دریافت می‌شوند. مجوز و شرایط استفاده آن‌ها تابع پروژه و ناشر همان فهرست‌هاست.

## یادآوری

این فایل خلاصه اطلاعیه است؛ مجوزها و اعلان‌های همراه هر بسته شخص ثالث باید در نسخه توزیعی نهایی نیز نگهداری شوند.
