(() => {
  let imageMode = 0;
  window.__miliBlockPopups = true;
  const placeholder = "data:image/svg+xml," + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="320" height="180"><rect width="100%" height="100%" fill="#d8d8dc"/><text x="50%" y="50%" text-anchor="middle" fill="#555" font-size="14">برای بارگذاری تصویر لمس کنید</text></svg>');
  const prepare = img => {
    if (!(img instanceof HTMLImageElement) || img.dataset.miliPrepared) return;
    const original = img.currentSrc || img.getAttribute("src") || "";
    if (!original || original.startsWith("data:") || original === window.location.href) return;
    img.dataset.miliPrepared = "1";
    img.dataset.miliOriginal = original;
    img.src = placeholder;
    img.style.filter = "blur(8px)";
    img.style.cursor = "zoom-in";
    img.addEventListener("click", () => {
      const url = img.dataset.miliOriginal;
      if (!url) return;
      browser.runtime.sendMessage({ type: "mili:allow-image", url }).catch(() => {}).finally(() => {
        const picture = img.closest("picture");
        picture?.querySelectorAll("source[srcset]").forEach(source => source.removeAttribute("srcset"));
        img.removeAttribute("srcset");
        img.removeAttribute("sizes");
        img.style.filter = "none";
        img.src = url;
        delete img.dataset.miliOriginal;
      });
    }, { once: true });
  };
  const apply = () => {
    if (imageMode === 1) document.querySelectorAll("img").forEach(prepare);
    if (imageMode === 2) {
      document.documentElement.classList.add("mili-no-images");
      if (!document.getElementById("mili-no-images-style")) {
        const style = document.createElement("style"); style.id = "mili-no-images-style";
        style.textContent = "img,picture,svg image{visibility:hidden!important}";
        (document.head || document.documentElement).appendChild(style);
      }
    }
  };
  try { browser.runtime.sendMessage({ type: "mili:get-settings" }).then(s => { imageMode = s?.imageMode || 0; window.__miliBlockPopups = !!s?.blockPopups; apply(); }).catch(() => {}); } catch (_) {}
  browser.storage.onChanged.addListener((changes, area) => {
    if (area !== "local") return;
    if (changes.imageMode) imageMode = changes.imageMode.newValue || 0;
    if (changes.blockPopups) window.__miliBlockPopups = !!changes.blockPopups.newValue;
    apply();
  });
  const observeDocument = () => {
    apply();
    new MutationObserver(apply).observe(document.documentElement, { childList: true, subtree: true });
  };
  if (document.documentElement) observeDocument();
  else document.addEventListener("DOMContentLoaded", observeDocument, { once: true });
  document.addEventListener("click", event => {
    if (!event.isTrusted) return;
    const link = event.target?.closest?.("a[target=_blank]");
    if (link && window.__miliBlockPopups) { event.preventDefault(); event.stopPropagation(); }
  }, true);
  const originalOpen = window.open;
  window.open = function(...args) {
    if (window.__miliBlockPopups) return null;
    return originalOpen.apply(this, args);
  };
})();
