package com.milichrome.browser.feature.telegram

/** TDLib-backed account client contract. No Telegram credentials belong in app preferences. */
interface TelegramGateway {
    val isAuthorized: Boolean
    suspend fun sendTextToBot(username: String, text: String): Result<Unit>
}
