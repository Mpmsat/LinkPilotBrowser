package com.milichrome.browser.core.browser

import android.content.Context
import org.mozilla.geckoview.GeckoRuntime
import org.mozilla.geckoview.GeckoSession
import org.mozilla.geckoview.GeckoSessionSettings

/** Process-wide owner of GeckoRuntime. Gecko permits one active runtime per app process. */
class BrowserEngine(context: Context) {
    val runtime: GeckoRuntime = RuntimeHolder.get(context.applicationContext)

    fun createSession(privateMode: Boolean = false): GeckoSession {
        val settings = GeckoSessionSettings.Builder()
            .usePrivateMode(privateMode)
            .useTrackingProtection(true)
            .build()
        val session = GeckoSession(settings)
        session.setContentDelegate(object : GeckoSession.ContentDelegate {})
        session.open(runtime)
        return session
    }

    private object RuntimeHolder {
        @Volatile private var instance: GeckoRuntime? = null
        fun get(context: Context): GeckoRuntime = instance ?: synchronized(this) {
            instance ?: GeckoRuntime.create(context).also { instance = it }
        }
    }
}
