package com.milichrome.browser.feature.telegram

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import java.security.KeyStore
import java.io.File
import java.lang.reflect.Constructor
import java.lang.reflect.Proxy
import java.security.SecureRandom
import java.util.concurrent.CopyOnWriteArrayList
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.os.Build

/** Real TDLib JNI adapter. TDLib's generated Java API is loaded from the checksum-pinned build bundle. */
class TdlibCenterClient(context: Context) : TelegramCenterContract {
    private val app = context.applicationContext
    private val main = Handler(Looper.getMainLooper())
    private val observers = CopyOnWriteArrayList<(TelegramUiState) -> Unit>()
    private val chats = linkedMapOf<Long, TelegramChat>()
    private val contacts = linkedMapOf<Long, TelegramContact>()
    private val messages = linkedMapOf<Long, MutableList<TelegramMessage>>()
    private val mediaFileIds = linkedMapOf<Pair<Long, Long>, Int>()
    private val lastReadOutboxIds = linkedMapOf<Long, Long>()
    private val apiCredentials = TelegramApiCredentialStore.load(app)
        ?: error("برای راه‌اندازی تلگرام، API ID و API Hash برنامه را در تنظیمات تلگرام وارد کن.")
    @Volatile private var state = TelegramUiState()
    @Volatile private var client: Any? = null
    val isAuthorized: Boolean get() = state.authStep == TelegramAuthStep.READY
    private val tdApi = "org.drinkless.tdlib.TdApi"
    private val clientApi = "org.drinkless.tdlib.Client"

    init {
        loadNativeLibraries()
        createClient()
    }

    private fun loadNativeLibraries() {
        System.loadLibrary("c++_shared")
        System.loadLibrary("cryptox")
        System.loadLibrary("sslx")
        System.loadLibrary("tdjni")
    }

    private fun createClient() {
        val clientClass = Class.forName(clientApi)
        val handlerClass = Class.forName("$clientApi\$ResultHandler")
        val callback = Proxy.newProxyInstance(handlerClass.classLoader, arrayOf(handlerClass)) { _, method, args ->
            if (method.name == "onResult" && !args.isNullOrEmpty()) handleTdObject(args[0])
            null
        }
        val create = clientClass.methods.first { it.name == "create" && it.parameterTypes.size == 3 }
        client = create.invoke(null, callback, null, null)
    }

    private fun send(function: Any, onResult: ((Any) -> Unit)? = null) {
        val target = client ?: return
        val functionClass = Class.forName("$tdApi\$Function")
        val handlerClass = Class.forName("$clientApi\$ResultHandler")
        val handler = Proxy.newProxyInstance(handlerClass.classLoader, arrayOf(handlerClass)) { _, method, args ->
            if (method.name == "onResult" && !args.isNullOrEmpty()) {
                val result = args[0]
                if (result.javaClass.simpleName == "Error") handleTdObject(result)
                else onResult?.invoke(result)
            }
            null
        }
        val method = target.javaClass.methods.first { it.name == "send" && it.parameterTypes.size == 2 && it.parameterTypes[0] == functionClass }
        method.invoke(target, function, handler)
    }

    private fun td(name: String, vararg args: Any?): Any {
        val type = Class.forName("$tdApi\$$name")
        fun compatible(parameter: Class<*>, value: Any?): Boolean {
            if (value == null) return !parameter.isPrimitive
            if (parameter.isInstance(value)) return true
            return when (parameter) {
                java.lang.Integer.TYPE -> value is Int
                java.lang.Long.TYPE -> value is Long
                java.lang.Boolean.TYPE -> value is Boolean
                java.lang.Double.TYPE -> value is Double
                java.lang.Float.TYPE -> value is Float
                java.lang.Short.TYPE -> value is Short
                java.lang.Byte.TYPE -> value is Byte
                java.lang.Character.TYPE -> value is Char
                else -> false
            }
        }
        val ctor: Constructor<*> = type.constructors.firstOrNull { constructor ->
            constructor.parameterTypes.size == args.size && constructor.parameterTypes.indices.all { i -> compatible(constructor.parameterTypes[i], args[i]) }
        } ?: error("TDLib API mismatch: compatible constructor $name(${args.size}) not found")
        return ctor.newInstance(*args)
    }

    private fun tdObject(name: String, values: Map<String, Any?> = emptyMap()): Any {
        val instance = Class.forName("$tdApi\$$name").getDeclaredConstructor().newInstance()
        values.forEach { (key, value) -> runCatching {
            val f = instance.javaClass.getField(key)
            val compatibleValue: Any? = when {
                f.type.isInstance(value) -> value
                f.type == IntArray::class.java && value is LongArray -> value.map { it.toInt() }.toIntArray()
                f.type == LongArray::class.java && value is IntArray -> value.map { it.toLong() }.toLongArray()
                f.type.isPrimitive && value is Number -> value
                f.type == java.lang.Boolean.TYPE && value is Boolean -> value
                value == null && !f.type.isPrimitive -> null
                else -> return@runCatching
            }
            when (f.type) {
                java.lang.Integer.TYPE -> f.setInt(instance, (compatibleValue as Number).toInt())
                java.lang.Long.TYPE -> f.setLong(instance, (compatibleValue as Number).toLong())
                java.lang.Boolean.TYPE -> f.setBoolean(instance, compatibleValue as Boolean)
                else -> f.set(instance, compatibleValue)
            }
        } }
        return instance
    }

    private fun setFlexibleField(target: Any, name: String, preferred: Any, fallback: Any?) {
        runCatching {
            val f = target.javaClass.getField(name)
            when {
                f.type.isInstance(preferred) -> f.set(target, preferred)
                fallback == null && !f.type.isPrimitive -> f.set(target, null)
                fallback != null && f.type.isInstance(fallback) -> f.set(target, fallback)
            }
        }
    }

    private fun field(value: Any?, name: String): Any? = runCatching {
        value?.javaClass?.getField(name)?.get(value)
    }.getOrNull()

    private fun handleTdObject(value: Any) {
        when (value.javaClass.simpleName) {
            "UpdateAuthorizationState" -> handleAuthorization(field(value, "authorizationState") ?: return)
            "UpdateNewChat", "UpdateChat" -> {
                val chat = field(value, "chat") ?: return
                upsertChat(chat)
            }
            "UpdateChatTitle", "UpdateChatLastMessage", "UpdateChatUnreadMentionCount", "UpdateChatReadInbox" -> {
                val id = (field(value, "chatId") as? Number)?.toLong() ?: return
                requestChat(id)
            }
            "UpdateNewMessage" -> {
                val message = field(value, "message") ?: return
                val chatId = (field(message, "chatId") as? Number)?.toLong() ?: 0L
                upsertMessage(message)
                if (chatId != 0L && state.selectedChat?.id != chatId && field(message, "isOutgoing") != true && field(value, "disableNotification") != true) notifyIncoming(chatId, message)
            }
            "UpdateMessageSendSucceeded" -> {
                val message = field(value, "message") ?: return
                val oldId = (field(value, "oldMessageId") as? Number)?.toLong() ?: 0L
                val chatId = (field(message, "chatId") as? Number)?.toLong() ?: return
                if (oldId != 0L) messages[chatId]?.removeAll { it.id == oldId }
                upsertMessage(message)
            }
            "UpdateMessageSendFailed" -> {
                val error = field(value, "errorMessage")?.toString().orEmpty()
                update { it.copy(statusText = "ارسال پیام ناموفق بود: $error") }
            }
            "UpdateChatReadOutbox" -> {
                val chatId = (field(value, "chatId") as? Number)?.toLong() ?: return
                val lastRead = (field(value, "lastReadOutboxMessageId") as? Number)?.toLong() ?: 0L
                lastReadOutboxIds[chatId] = lastRead
                messages[chatId]?.replaceAll { m -> if (m.outgoing && m.id <= lastRead) m.copy(isRead = true) else m }
                publish()
            }
            "UpdateFile" -> {
                val file = field(value, "file") ?: return
                val id = (field(file, "id") as? Number)?.toInt() ?: return
                val local = field(file, "local")
                val path = field(local, "path")?.toString()?.takeIf { it.isNotBlank() }
                val complete = field(local, "isDownloadingCompleted") == true
                if (complete && path != null) {
                    messages.forEach { (chatId, list) ->
                        list.replaceAll { m -> if (mediaFileIds[chatId to m.id] == id) m.copy(mediaPath = path) else m }
                    }
                    publish()
                }
            }
            "UpdateUser" -> {
                val user = field(value, "user") ?: return
                upsertContact(user)
            }
            "UpdateMessageContent" -> {
                val chatId = (field(value, "chatId") as? Number)?.toLong() ?: return
                val messageId = (field(value, "messageId") as? Number)?.toLong() ?: return
                val content = field(value, "newContent")
                val list = messages[chatId] ?: return
                val index = list.indexOfFirst { it.id == messageId }
                if (index >= 0) list[index] = list[index].copy(text = messageText(content))
                publish()
            }
            "Error" -> {
                val code = field(value, "code")
                val message = field(value, "message")?.toString().orEmpty()
                update { it.copy(isLoading = false, statusText = "خطای تلگرام ($code): $message") }
            }
        }
    }

    private fun handleAuthorization(auth: Any) {
        when (auth.javaClass.simpleName) {
            "AuthorizationStateWaitTdlibParameters" -> {
                val root = File(app.filesDir, "tdlib").apply { mkdirs() }
                val dbKey = databaseKey()
                val params = td(
                    "SetTdlibParameters",
                    false,
                    File(root, "database").apply { mkdirs() }.absolutePath,
                    File(root, "files").apply { mkdirs() }.absolutePath,
                    dbKey,
                    true, true, true, true,
                    apiCredentials.apiId,
                    apiCredentials.apiHash,
                    app.resources.configuration.locales[0].toLanguageTag(),
                    android.os.Build.MODEL ?: "Android",
                    android.os.Build.VERSION.RELEASE ?: "Android",
                    "Mili Browser 0.4.2"
                )
                send(params)
                update { it.copy(statusText = "در حال راه‌اندازی امن تلگرام…", isLoading = true) }
            }
            "AuthorizationStateWaitPhoneNumber" -> update { it.copy(authStep = TelegramAuthStep.PHONE, statusText = "شماره تلفن را با کد کشور وارد کنید", isLoading = false) }
            "AuthorizationStateWaitCode" -> update { it.copy(authStep = TelegramAuthStep.CODE, statusText = "کد تأیید ارسال‌شده را وارد کنید", isLoading = false) }
            "AuthorizationStateWaitPassword" -> update { it.copy(authStep = TelegramAuthStep.PASSWORD, statusText = "رمز تأیید دومرحله‌ای را وارد کنید", isLoading = false) }
            "AuthorizationStateReady" -> {
                update { it.copy(authStep = TelegramAuthStep.READY, statusText = "متصل شد", isLoading = false) }
                disableAutomaticMediaDownloads()
                loadChats()
            }
            "AuthorizationStateLoggingOut" -> update { it.copy(statusText = "در حال خروج از حساب…", isLoading = true) }
            "AuthorizationStateClosing" -> update { it.copy(statusText = "در حال بستن نشست…", isLoading = true) }
            "AuthorizationStateClosed" -> {
                update { it.copy(authStep = TelegramAuthStep.PHONE, statusText = "نشست بسته شد؛ آمادهٔ ورود دوباره", isLoading = false) }
                main.post { runCatching { createClient() }.onFailure { error -> update { it.copy(statusText = error.message ?: "راه‌اندازی دوباره انجام نشد") } } }
            }
            else -> update { it.copy(statusText = "وضعیت ورود: ${auth.javaClass.simpleName}", isLoading = false) }
        }
    }

    private fun databaseKey(): ByteArray {
        val prefs = app.getSharedPreferences("tdlib_secure_bootstrap", Context.MODE_PRIVATE)
        val key = getOrCreateKeystoreKey()
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        val encrypted = prefs.getString("db_key_ciphertext", null)
        val iv = prefs.getString("db_key_iv", null)
        if (encrypted != null && iv != null) {
            cipher.init(Cipher.DECRYPT_MODE, key, javax.crypto.spec.GCMParameterSpec(128, Base64.decode(iv, Base64.NO_WRAP)))
            return cipher.doFinal(Base64.decode(encrypted, Base64.NO_WRAP))
        }
        val bytes = ByteArray(32).also { SecureRandom().nextBytes(it) }
        cipher.init(Cipher.ENCRYPT_MODE, key)
        val ciphertext = cipher.doFinal(bytes)
        prefs.edit()
            .putString("db_key_ciphertext", Base64.encodeToString(ciphertext, Base64.NO_WRAP))
            .putString("db_key_iv", Base64.encodeToString(cipher.iv, Base64.NO_WRAP))
            .commit()
        return bytes
    }

    private fun getOrCreateKeystoreKey(): SecretKey {
        val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        val alias = "mili_tdlib_database_key"
        (store.getKey(alias, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setRandomizedEncryptionRequired(true)
            .build())
        return generator.generateKey()
    }

    private fun upsertChat(raw: Any) {
        val id = (field(raw, "id") as? Number)?.toLong() ?: return
        val type = field(raw, "type")
        val bot = false
        val kind = when (type?.javaClass?.simpleName) {
            "ChatTypeBasicGroup" -> "گروه"
            "ChatTypeSupergroup" -> if (field(type, "isChannel") == true) "کانال" else "سوپرگروه"
            "ChatTypeSecret" -> "محرمانه"
            "ChatTypePrivate" -> "خصوصی"
            else -> "گفتگو"
        }
        val chat = TelegramChat(
            id = id,
            title = field(raw, "title")?.toString().orEmpty().ifBlank { "گفتگو $id" },
            lastMessage = messageText(field(raw, "lastMessage")),
            unreadCount = (field(raw, "unreadCount") as? Number)?.toInt() ?: 0,
            isBot = bot,
            kind = kind
        )
        chats[id] = chat
        val lastRead = (field(raw, "lastReadOutboxMessageId") as? Number)?.toLong()
        if (lastRead != null) lastReadOutboxIds[id] = maxOf(lastReadOutboxIds[id] ?: 0L, lastRead)
        publish()
    }

    private fun disableAutomaticMediaDownloads() {
        // TDLib applies this per network type. Keep every automatic category disabled.
        listOf("NetworkTypeMobile", "NetworkTypeWiFi", "NetworkTypeOther").forEach { networkType ->
            runCatching {
                val settings = tdObject("AutoDownloadSettings", mapOf(
                    "isAutoDownloadEnabled" to false,
                    "maxPhotoFileSize" to 0L,
                    "maxVideoFileSize" to 0L,
                    "maxOtherFileSize" to 0L,
                    "videoUploadBitrate" to 0,
                    "preloadLargeVideos" to false,
                    "preloadNextAudio" to false,
                    "preloadStories" to false
                ))
                send(td("SetAutoDownloadSettings", settings, tdObject(networkType)))
            }.onFailure { update { it.copy(statusText = "دانلود خودکار رسانه غیرفعال نشد: ${it.message}") } }
        }
    }

    fun downloadMessageMedia(chatId: Long, messageId: Long) {
        val fileId = mediaFileIds[chatId to messageId]
        if (fileId == null) {
            update { it.copy(statusText = "شناسه فایل پیوست در دسترس نیست") }
            return
        }
        runCatching {
            send(tdObject("DownloadFile", mapOf(
                "fileId" to fileId, "priority" to 16, "offset" to 0L,
                "limit" to 0L, "synchronous" to false
            )))
        }.onFailure { update { it.copy(statusText = "شروع دانلود ناموفق بود: ${it.message}") } }
    }

    private fun requestChat(id: Long) {
        send(td("GetChat", id)) { result ->
            if (result.javaClass.simpleName == "Chat") upsertChat(result)
        }
    }

    private fun upsertMessage(raw: Any) {
        val chatId = (field(raw, "chatId") as? Number)?.toLong() ?: return
        val id = (field(raw, "id") as? Number)?.toLong() ?: return
        val timestamp = (field(raw, "date") as? Number)?.toLong() ?: 0L
        val outgoing = field(raw, "isOutgoing") as? Boolean ?: false
        val content = field(raw, "content")
        val mediaId = extractMediaFileId(content)
        if (mediaId != null) {
            // Store the file id only. Media is never downloaded automatically.
            mediaFileIds[chatId to id] = mediaId
        }
        val read = outgoing && id <= (lastReadOutboxIds[chatId] ?: 0L)
        val item = TelegramMessage(id, chatId, messageText(content), outgoing, timestamp, null, mediaMimeType(content), read)
        val list = messages.getOrPut(chatId) { mutableListOf() }
        if (list.none { it.id == id }) list.add(item)
        list.sortBy { it.timestamp }
        publish()
    }

    private fun messageText(content: Any?): String {
        if (content == null) return ""
        return when (content.javaClass.simpleName) {
            "MessageText" -> field(field(content, "text"), "text")?.toString().orEmpty()
            "MessagePhoto" -> "📷 تصویر"
            "MessageVideo" -> "🎬 ویدئو"
            "MessageDocument" -> "📎 فایل"
            "MessageAudio" -> "🎵 فایل صوتی"
            "MessageAnimation" -> "🎞 پویانمایی"
            "MessageVoiceNote", "MessageVoice" -> "🎤 پیام صوتی"
            "MessageSticker" -> "استیکر"
            else -> ""
        }
    }

    private fun mediaMimeType(content: Any?): String? = when (content?.javaClass?.simpleName) {
        "MessagePhoto" -> "image/*"
        "MessageVideo" -> "video/*"
        "MessageDocument" -> field(field(content, "document"), "mimeType")?.toString() ?: "application/octet-stream"
        "MessageAudio" -> field(field(content, "audio"), "mimeType")?.toString() ?: "audio/*"
        "MessageVoice", "MessageVoiceNote" -> "audio/ogg"
        "MessageAnimation" -> "video/mp4"
        else -> null
    }

    private fun extractMediaFileId(content: Any?): Int? {
        if (content == null) return null
        val payloadName = when (content.javaClass.simpleName) {
            "MessagePhoto" -> "photo"
            "MessageVideo" -> "video"
            "MessageDocument" -> "document"
            "MessageAudio" -> "audio"
            "MessageVoice", "MessageVoiceNote" -> "voice"
            "MessageAnimation" -> "animation"
            else -> return null
        }
        val payload = field(content, payloadName) ?: return null
        val file = when (payloadName) {
            "photo" -> {
                val sizes = field(payload, "sizes") as? Array<*> ?: return null
                val best = sizes.filterNotNull().maxByOrNull { (field(it, "width") as? Number)?.toInt() ?: 0 } ?: return null
                field(best, "photo") ?: field(best, "file")
            }
            else -> field(payload, payloadName) ?: field(payload, "file")
        } ?: return null
        return (field(file, "id") as? Number)?.toInt()
    }

    private fun notifyIncoming(chatId: Long, raw: Any) {
        runCatching {
            val manager = app.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val channelId = "mili_telegram_messages"
            if (Build.VERSION.SDK_INT >= 26 && manager.getNotificationChannel(channelId) == null) {
                manager.createNotificationChannel(NotificationChannel(channelId, "پیام‌های تلگرام", NotificationManager.IMPORTANCE_DEFAULT))
            }
            val chat = chats[chatId]
            val content = messageText(field(raw, "content")).ifBlank { "پیام جدید" }
            val intent = Intent(app, TelegramCenterActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            val pending = PendingIntent.getActivity(app, chatId.toInt(), intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            val builder = if (Build.VERSION.SDK_INT >= 26) android.app.Notification.Builder(app, channelId) else android.app.Notification.Builder(app)
            val notification = builder.setSmallIcon(android.R.drawable.sym_action_chat).setContentTitle(chat?.title ?: "تلگرام")
                .setContentText(content).setContentIntent(pending).setAutoCancel(true).build()
            manager.notify(chatId.toInt(), notification)
        }
    }

    private fun upsertContact(user: Any) {
        val id = (field(user, "id") as? Number)?.toLong() ?: return
        val first = field(user, "firstName")?.toString().orEmpty()
        val last = field(user, "lastName")?.toString().orEmpty()
        val username = field(user, "username")?.toString()?.takeIf { it.isNotBlank() }
            ?: (field(field(user, "usernames"), "activeUsernames") as? Array<*>)?.firstOrNull()?.toString().orEmpty()
        contacts[id] = TelegramContact(id, "$first $last".trim().ifBlank { "کاربر $id" }, username)
        publish()
    }

    override fun observe(observer: (TelegramUiState) -> Unit) {
        observers += observer
        main.post { observer(state) }
    }

    override fun requestPhone(phoneNumber: String) {
        val value = phoneNumber.trim()
        if (!value.startsWith("+")) {
            update { it.copy(statusText = "شماره را همراه با کد کشور و علامت + وارد کنید") }
            return
        }
        update { it.copy(isLoading = true, statusText = "در حال درخواست کد تأیید…") }
        send(td("SetAuthenticationPhoneNumber", value, null))
    }

    override fun submitCode(code: String) {
        update { it.copy(isLoading = true, statusText = "در حال بررسی کد…") }
        send(td("CheckAuthenticationCode", code.trim()))
    }

    override fun submitPassword(password: String) {
        update { it.copy(isLoading = true, statusText = "در حال بررسی رمز دومرحله‌ای…") }
        send(td("CheckAuthenticationPassword", password))
    }

    override fun showChatList() {
        state.selectedChat?.let { chat -> runCatching { send(td("CloseChat", chat.id)) } }
        update { it.copy(selectedChat = null, messages = emptyList(), isLoading = false) }
        loadChats()
    }

    override fun loadChats() {
        update { it.copy(isLoading = true) }
        val list = td("ChatListMain")
        send(td("LoadChats", list, 100))
        main.postDelayed({ update { it.copy(chats = chats.values.sortedByDescending { c -> c.unreadCount.toLong() }, isLoading = false) } }, 1200)
    }

    override fun openChat(chatId: Long) {
        state.selectedChat?.let { previous -> if (previous.id != chatId) runCatching { send(td("CloseChat", previous.id)) } }
        runCatching { send(td("OpenChat", chatId)) }
        val selected = chats[chatId] ?: TelegramChat(chatId, "گفتگو $chatId")
        update { it.copy(selectedChat = selected, messages = messages[chatId].orEmpty(), isLoading = true) }
        send(td("GetChatHistory", chatId, 0L, 0, 50, false)) { result ->
            if (result.javaClass.simpleName == "Messages") {
                val array = field(result, "messages") as? Array<*> ?: emptyArray<Any>()
                array.filterNotNull().forEach(::upsertMessage)
            }
            val ids = messages[chatId].orEmpty().map { it.id }.toLongArray()
            if (ids.isNotEmpty()) runCatching { send(tdObject("ViewMessages", mapOf("chatId" to chatId, "messageIds" to ids, "forceRead" to true))) }
            update { it.copy(messages = messages[chatId].orEmpty(), isLoading = false) }
        }
    }

    override fun loadOlderMessages(chatId: Long) {
        val first = messages[chatId]?.minByOrNull { it.id }
        send(td("GetChatHistory", chatId, first?.id ?: 0L, 0, 50, false)) { result ->
            if (result.javaClass.simpleName == "Messages") {
                val array = field(result, "messages") as? Array<*> ?: emptyArray<Any>()
                array.filterNotNull().forEach(::upsertMessage)
            }
        }
    }

    override fun sendText(chatId: Long, text: String) {
        val entities = java.lang.reflect.Array.newInstance(Class.forName("$tdApi\$TextEntity"), 0)
        val formatted = td("FormattedText", text, entities)
        val content = tdObject("InputMessageText", mapOf("clearDraft" to true, "disableWebPagePreview" to false, "entities" to entities))
        setFlexibleField(content, "text", formatted, text)
        val request = tdObject("SendMessage", mapOf("chatId" to chatId, "inputMessageContent" to content))
        send(request)
    }

    override fun sendMedia(chatId: Long, path: String, mimeType: String, caption: String) {
        runCatching {
            val input = tdObject("InputFileLocal", mapOf("path" to path))
            val contentName = when {
                mimeType.startsWith("image/") -> "InputMessagePhoto"
                mimeType.startsWith("video/") -> "InputMessageVideo"
                mimeType.startsWith("audio/") -> if (mimeType.contains("ogg") || mimeType.contains("opus")) "InputMessageVoice" else "InputMessageAudio"
                else -> "InputMessageDocument"
            }
            val content = tdObject(contentName)
            val fileField = when (contentName) {
                "InputMessagePhoto" -> "photo"
                "InputMessageVideo" -> "video"
                "InputMessageAudio" -> "audio"
                "InputMessageVoice" -> "voice"
                else -> "document"
            }
            content.javaClass.getField(fileField).set(content, input)
            val captionEntities = java.lang.reflect.Array.newInstance(Class.forName("$tdApi\$TextEntity"), 0)
            val formattedCaption = td("FormattedText", caption, captionEntities)
            setFlexibleField(content, "caption", formattedCaption, caption)
            if (contentName == "InputMessageVoice" || contentName == "InputMessageAudio") {
                val duration = runCatching {
                    val retriever = android.media.MediaMetadataRetriever()
                    retriever.setDataSource(path)
                    val seconds = retriever.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()?.div(1000)?.toInt() ?: 0
                    retriever.release()
                    seconds
                }.getOrDefault(0)
                runCatching { content.javaClass.getField("duration").setInt(content, duration) }
            }
            val request = tdObject("SendMessage", mapOf("chatId" to chatId, "inputMessageContent" to content))
            send(request)
        }.onFailure { error -> update { it.copy(statusText = "ارسال فایل ناموفق: ${error.message}") } }
    }

    override fun loadContacts(onLoaded: (() -> Unit)?) {
        send(tdObject("GetContacts")) { result ->
            val objects = field(result, "users") as? Array<*>
            val ids = field(result, "userIds") as? IntArray
            if (objects != null) objects.filterNotNull().forEach(::upsertContact)
            if (ids != null && ids.isNotEmpty()) {
                val remaining = java.util.concurrent.atomic.AtomicInteger(ids.size)
                val finished = java.util.concurrent.atomic.AtomicBoolean(false)
                val finish = { if (finished.compareAndSet(false, true)) main.post { onLoaded?.invoke() } }
                ids.forEach { userId ->
                    send(td("GetUser", userId)) { user ->
                        if (user.javaClass.simpleName == "User") upsertContact(user)
                        if (remaining.decrementAndGet() == 0) finish()
                    }
                }
                main.postDelayed({ finish() }, 2500)
            } else {
                update { it.copy(contacts = contacts.values.sortedBy { c -> c.name }) }
                main.post { onLoaded?.invoke() }
            }
        }
    }

    override fun createPrivateChat(userId: Long) {
        send(tdObject("CreatePrivateChat", mapOf("userId" to userId.toInt(), "force" to false))) { result ->
            if (result.javaClass.simpleName == "Chat") {
                upsertChat(result)
                val id = (field(result, "id") as? Number)?.toLong() ?: return@send
                openChat(id)
            }
        }
    }

    override fun sendTextToUsername(username: String, text: String) {
        val clean = username.removePrefix("@").trim()
        send(td("SearchPublicChat", clean)) { result ->
            if (result.javaClass.simpleName == "Chat") {
                val id = (field(result, "id") as? Number)?.toLong() ?: return@send
                sendText(id, text)
            } else {
                update { it.copy(statusText = "ربات یا کاربر @$clean پیدا نشد") }
            }
        }
    }

    override fun logout() { send(td("LogOut")) }

    override fun close() {
        // Keep the TDLib client alive across Activity recreation; the app process owns the session.
        observers.clear()
    }

    private fun update(transform: (TelegramUiState) -> TelegramUiState) {
        state = transform(state)
        publish()
    }

    private fun publish() {
        val snapshot = state.copy(
            chats = chats.values.sortedByDescending { it.unreadCount },
            contacts = contacts.values.sortedBy { it.name },
            messages = state.selectedChat?.let { messages[it.id].orEmpty().toList() } ?: state.messages
        )
        state = snapshot
        main.post { observers.forEach { observer -> runCatching { observer(snapshot) } } }
    }
}

/** Process-wide owner prevents duplicate TDLib databases when the Activity is recreated. */
object TdlibCenterRuntime {
    @Volatile private var instance: TdlibCenterClient? = null
    @Synchronized fun get(context: Context): TdlibCenterClient {
        return instance ?: TdlibCenterClient(context.applicationContext).also { instance = it }
    }
}
