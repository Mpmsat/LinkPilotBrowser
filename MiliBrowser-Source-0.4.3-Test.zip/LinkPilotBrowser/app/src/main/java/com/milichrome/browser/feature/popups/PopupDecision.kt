package com.milichrome.browser.feature.popups

enum class PopupDecision { ASK, ALWAYS_ALLOW, ALWAYS_BLOCK }

data class PopupRequest(val sourceUrl: String, val destinationUrl: String)
