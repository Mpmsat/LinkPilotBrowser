package com.milichrome.browser.feature.telegram

import android.content.Context
import android.util.Base64
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import com.milichrome.browser.BuildConfig
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import java.security.KeyStore

data class TelegramApiCredentials(val apiId: Int, val apiHash: String)

/** Stores the user's Telegram application credentials encrypted with an Android Keystore key. */
object TelegramApiCredentialStore {
    private const val PREFS = "mili_telegram_api_secure"
    private const val ALIAS = "mili_telegram_api_credentials_v1"

    fun load(context: Context): TelegramApiCredentials? {
        if (BuildConfig.TDLIB_API_ID > 0 && BuildConfig.TDLIB_API_HASH.isNotBlank()) {
            return TelegramApiCredentials(BuildConfig.TDLIB_API_ID, BuildConfig.TDLIB_API_HASH)
        }
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val blob = prefs.getString("blob", null) ?: return null
        val iv = prefs.getString("iv", null) ?: return null
        return runCatching {
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, Base64.decode(iv, Base64.NO_WRAP)))
            val decoded = cipher.doFinal(Base64.decode(blob, Base64.NO_WRAP)).toString(Charsets.UTF_8)
            val parts = decoded.split("\n", limit = 2)
            val id = parts[0].toInt()
            val hash = parts.getOrElse(1) { "" }
            if (id > 0 && hash.length >= 20) TelegramApiCredentials(id, hash) else null
        }.getOrNull()
    }

    fun save(context: Context, apiId: Int, apiHash: String) {
        require(apiId > 0) { "API ID باید عدد مثبت باشد" }
        require(apiHash.length >= 20) { "API Hash معتبر نیست" }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key())
        val encrypted = cipher.doFinal("$apiId\n$apiHash".toByteArray(Charsets.UTF_8))
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString("blob", Base64.encodeToString(encrypted, Base64.NO_WRAP))
            .putString("iv", Base64.encodeToString(cipher.iv, Base64.NO_WRAP))
            .commit()
    }

    private fun key(): SecretKey {
        val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (store.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setRandomizedEncryptionRequired(true)
            .build())
        return generator.generateKey()
    }
}
