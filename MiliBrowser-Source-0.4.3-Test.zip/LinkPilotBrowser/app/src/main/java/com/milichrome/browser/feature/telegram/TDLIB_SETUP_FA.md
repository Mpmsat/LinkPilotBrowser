# راه‌اندازی TDLib در Mili Browser

## بستهٔ native قفل‌شده

- TDLib: `1.8.67`
- بسته: `CodexofLost/tdlib-packed`، تگ `v1.8.67`
- منشأ API و باینری‌ها: `TGX-Android/tdlib`، commit `a032dcf147860482bbf96a6c9206faf63d335ab0`
- commit منبع TDLib: `d1085f9cebc5a62379991ae1652673954f229c1f`
- SHA-256 آرشیو: `1050f0311eb4a6e0edd417612f6787707e7bb917632b1b7527ea648d331bcb4f`

در اولین اجرای Gradle، task با نام `prepareTdlib` آرشیو را از GitHub Releases دریافت می‌کند، SHA-256 را بررسی می‌کند و `Client.java`، `TdApi.java` و کتابخانه‌های native را به source setهای پروژه اضافه می‌کند. اگر checksum یا یکی از ABIها ناقص باشد، build متوقف می‌شود. فایل‌های باینری به‌صورت دستی یا ساختگی تولید نشده‌اند.

ABIهای بسته: `arm64-v8a`، `armeabi-v7a`، `x86_64` و `x86`. تنظیم فعلی اپ برای خروجی گوشی، `arm64-v8a` است.

## API ID و API Hash

برای استفاده از TDLib باید API ID و API Hash مخصوص برنامه از `my.telegram.org` دریافت شود. این مقادیر را در فایل شخصی Gradle کاربر قرار بده؛ آن‌ها را در مخزن یا فایل ZIP عمومی ننویس:

`~/.gradle/gradle.properties`

```properties
MILI_TDLIB_API_ID=123456
MILI_TDLIB_API_HASH=your_api_hash_here
```

مقادیر بالا نمونه‌اند و باید با اطلاعات واقعی برنامه جایگزین شوند. بدون این دو مقدار، صفحه تلگرام پیام راهنما نشان می‌دهد و ورود را آغاز نمی‌کند.

## پیاده‌سازی

`TdlibCenterClient.kt` از `org.drinkless.tdlib.Client` و `TdApi` نسخهٔ قفل‌شده استفاده می‌کند. راه‌اندازی native با ترتیب `c++_shared`، `cryptox`، `sslx` و `tdjni` انجام می‌شود. وضعیت مجوز/ورود، شماره، کد، رمز دومرحله‌ای، گفتگوها، تاریخچه و ارسال متن به رابط داخلی متصل شده‌اند.

کلید رمزگذاری پایگاه داده TDLib با Android Keystore محافظت می‌شود. نشست TDLib در سطح process نگه داشته می‌شود تا با بازسازی Activity، دیتابیس هم‌زمان توسط دو Client باز نشود.

## محدودیت آزمون

این محیط Android SDK/Gradle و دسترسی مستقیم شبکه برای دریافت asset باینری ندارد؛ بنابراین build واقعی APK، بارگذاری JNI روی دستگاه و ورود حساب از اینجا قابل ادعا نیست. خود Gradle در محیط build، آرشیو واقعی را با checksum بالا دریافت و قبل از compile بررسی می‌کند. پس از اجرای build آنلاین، باید در APK وجود `libtdjni.so`، `libcryptox.so`، `libsslx.so` و `libc++_shared.so` بررسی شود.

## مجوزها

TDLib تحت Boost Software License 1.0 و کتابخانه‌های OpenSSL همراه بسته طبق مجوزهای اعلام‌شده در upstream توزیع شده‌اند. فایل‌های مجوز و provenance بستهٔ upstream مرجع نهایی هستند.
