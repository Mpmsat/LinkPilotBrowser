package com.milichrome.browser.core.browser

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Small local store for bookmarks, history and per-origin Shield overrides. */
class BrowserDataStore(context: Context) {
    private val prefs = context.getSharedPreferences("mili_browser_data_v1", Context.MODE_PRIVATE)

    data class Entry(val title: String, val url: String, val time: Long = System.currentTimeMillis())

    fun bookmarks(): List<Entry> = read("bookmarks")
    fun history(): List<Entry> = read("history")

    fun addBookmark(title: String, url: String): Boolean {
        if (url.isBlank() || url == "about:blank") return false
        val all = bookmarks().filterNot { it.url == url }.toMutableList()
        all.add(Entry(title.ifBlank { url }, url))
        write("bookmarks", all.takeLast(500))
        return true
    }

    fun removeBookmark(url: String) = write("bookmarks", bookmarks().filterNot { it.url == url })

    fun addHistory(title: String, url: String) {
        if (!url.startsWith("http://") && !url.startsWith("https://")) return
        val all = history().filterNot { it.url == url }.toMutableList()
        all.add(Entry(title.ifBlank { url }, url))
        write("history", all.takeLast(1000))
    }

    fun clearHistory() = write("history", emptyList())

    fun globalShield(): JSONObject = runCatching {
        JSONObject(prefs.getString("shield_global", null) ?: "{}")
    }.getOrDefault(JSONObject())

    fun saveGlobalShield(values: JSONObject) { prefs.edit().putString("shield_global", values.toString()).apply() }

    fun siteShield(host: String): JSONObject = runCatching {
        JSONObject(prefs.getString("shield_site_$host", null) ?: "{}")
    }.getOrDefault(JSONObject())

    fun saveSiteShield(host: String, values: JSONObject) {
        prefs.edit().putString("shield_site_$host", values.toString()).apply()
    }

    fun blockedHosts(): Set<String> = prefs.getStringSet("manual_blocked_hosts", emptySet())?.toSet() ?: emptySet()
    fun saveBlockedHosts(hosts: Set<String>) { prefs.edit().putStringSet("manual_blocked_hosts", hosts.toSet()).apply() }

    private fun read(key: String): List<Entry> = runCatching {
        val array = JSONArray(prefs.getString(key, "[]"))
        (0 until array.length()).mapNotNull { i ->
            val o = array.optJSONObject(i) ?: return@mapNotNull null
            Entry(o.optString("title"), o.optString("url"), o.optLong("time"))
        }
    }.getOrDefault(emptyList())

    private fun write(key: String, entries: List<Entry>) {
        val array = JSONArray()
        entries.forEach { e -> array.put(JSONObject().put("title", e.title).put("url", e.url).put("time", e.time)) }
        prefs.edit().putString(key, array.toString()).apply()
    }
}
