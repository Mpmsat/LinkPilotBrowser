package com.milichrome.browser.core.privacy

/** Per-site privacy preferences. Enforcement is connected to the engine in the Shield phase. */
data class SiteProtectionSettings(
    val blockAds: Boolean = true,
    val blockTrackers: Boolean = true,
    val blockThirdPartyCookies: Boolean = true,
    val blockScripts: Boolean = false,
    val fingerprintProtection: Boolean = true,
    val upgradeHttps: Boolean = true,
    val blockSocialTrackers: Boolean = true
)
