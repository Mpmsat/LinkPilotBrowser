package com.milichrome.browser.feature.images

enum class ImageMode {
    ORIGINAL,
    ORIGINAL_BLUR,
    NO_IMAGES
}
