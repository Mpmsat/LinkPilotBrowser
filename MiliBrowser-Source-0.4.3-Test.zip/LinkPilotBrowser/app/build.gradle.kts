import java.net.URL
import java.security.MessageDigest
import java.util.zip.ZipFile

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val tdlibVersion = "1.8.67"
val tdlibArchiveUrl = "https://github.com/CodexofLost/tdlib-packed/releases/download/v$tdlibVersion/tdlib-v$tdlibVersion.zip"
val tdlibSha256 = "1050f0311eb4a6e0edd417612f6787707e7bb917632b1b7527ea648d331bcb4f"
val tdlibGeneratedRoot = layout.buildDirectory.dir("generated/tdlib")

val prepareTdlib by tasks.registering {
    val archive = layout.buildDirectory.file("tdlib/tdlib-v$tdlibVersion.zip")
    outputs.dir(tdlibGeneratedRoot)
    outputs.file(archive)
    doLast {
        val archiveFile = archive.get().asFile
        archiveFile.parentFile.mkdirs()
        if (!archiveFile.exists() || sha256(archiveFile) != tdlibSha256) {
            archiveFile.delete()
            URL(tdlibArchiveUrl).openConnection().apply {
                connectTimeout = 30000
                readTimeout = 120000
                setRequestProperty("User-Agent", "MiliBrowser-TDLib-setup")
            }.getInputStream().use { input -> archiveFile.outputStream().use { output -> input.copyTo(output) } }
        }
        val actualHash = sha256(archiveFile)
        check(actualHash == tdlibSha256) { "TDLib archive SHA-256 mismatch: $actualHash" }

        val root = tdlibGeneratedRoot.get().asFile
        val javaRoot = root.resolve("java")
        val jniRoot = root.resolve("jniLibs")
        root.deleteRecursively()
        javaRoot.mkdirs(); jniRoot.mkdirs()
        ZipFile(archiveFile).use { zip ->
            val entries = zip.entries()
            while (entries.hasMoreElements()) {
                val entry = entries.nextElement()
                if (entry.isDirectory) continue
                val name = entry.name.replace('\\', '/')
                val javaMarker = name.indexOf("java/org/drinkless/tdlib/")
                val libsMarker = name.indexOf("libs/")
                val target = when {
                    javaMarker >= 0 -> javaRoot.resolve(name.substring(javaMarker + "java/".length))
                    libsMarker >= 0 -> jniRoot.resolve(name.substring(libsMarker + "libs/".length))
                    else -> null
                } ?: continue
                target.parentFile.mkdirs()
                zip.getInputStream(entry).use { input -> target.outputStream().use { output -> input.copyTo(output) } }
            }
        }
        check(javaRoot.resolve("org/drinkless/tdlib/Client.java").isFile) { "TDLib Client.java missing from verified archive" }
        check(javaRoot.resolve("org/drinkless/tdlib/TdApi.java").isFile) { "TDLib TdApi.java missing from verified archive" }
        check(jniRoot.resolve("arm64-v8a/libtdjni.so").isFile) { "TDLib arm64-v8a/libtdjni.so missing" }
        listOf("arm64-v8a", "armeabi-v7a", "x86_64", "x86").forEach { abi ->
            check(jniRoot.resolve("$abi/libtdjni.so").isFile) { "TDLib libtdjni.so missing for $abi" }
            check(jniRoot.resolve("$abi/libcryptox.so").isFile) { "TDLib libcryptox.so missing for $abi" }
            check(jniRoot.resolve("$abi/libsslx.so").isFile) { "TDLib libsslx.so missing for $abi" }
            check(jniRoot.resolve("$abi/libc++_shared.so").isFile) { "TDLib libc++_shared.so missing for $abi" }
        }
    }
}

fun sha256(file: java.io.File): String = MessageDigest.getInstance("SHA-256").digest(file.readBytes()).joinToString("") { "%02x".format(it) }

android {
    namespace = "com.milichrome.browser"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.milichrome.browser"
        minSdk = 26
        targetSdk = 35
        versionCode = 7
        versionName = "0.4.3-browser-fixes"
        ndk { abiFilters += listOf("arm64-v8a") }
        val apiId = (project.findProperty("MILI_TDLIB_API_ID") as String?) ?: "0"
        val apiHash = (project.findProperty("MILI_TDLIB_API_HASH") as String?) ?: ""
        buildConfigField("int", "TDLIB_API_ID", apiId)
        buildConfigField("String", "TDLIB_API_HASH", "\"$apiHash\"")
    }

    buildFeatures { buildConfig = true }
    sourceSets["main"].java.srcDir(tdlibGeneratedRoot.map { it.dir("java") })
    sourceSets["main"].jniLibs.srcDir(tdlibGeneratedRoot.map { it.dir("jniLibs") })

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlin {
        compilerOptions {
            jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17)
        }
    }

    packaging {
        jniLibs { useLegacyPackaging = true }
        resources { excludes += setOf("META-INF/LICENSE*", "META-INF/NOTICE*") }
    }
}

tasks.matching { it.name == "preBuild" }.configureEach { dependsOn(prepareTdlib) }

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("org.mozilla.geckoview:geckoview-arm64-v8a:150.0.20260511200624")
}
