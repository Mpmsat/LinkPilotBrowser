#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"

if ! command -v java >/dev/null 2>&1; then
  echo "ERROR: Java 17 is required." >&2; exit 2
fi
if ! command -v gradle >/dev/null 2>&1; then
  echo "ERROR: Gradle 8.13 is required (the project does not bundle a Gradle wrapper)." >&2; exit 2
fi
if [[ -z "${ANDROID_HOME:-}${ANDROID_SDK_ROOT:-}" ]]; then
  echo "ERROR: Set ANDROID_HOME or ANDROID_SDK_ROOT to an installed Android SDK." >&2; exit 2
fi

SDK="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-}}"
if [[ ! -d "$SDK/platforms/android-36" ]]; then
  echo "ERROR: Android SDK Platform 36 is missing. Install platforms;android-36." >&2; exit 2
fi
if [[ ! -d "$SDK/build-tools/36.0.0" ]]; then
  echo "ERROR: Android Build Tools 36.0.0 are missing." >&2; exit 2
fi

gradle --no-daemon --stacktrace :app:assembleDebug
APK="$ROOT/app/build/outputs/apk/debug/app-debug.apk"
test -s "$APK"
echo
echo "BUILD SUCCESSFUL"
echo "APK: $APK"
ls -lh "$APK"
