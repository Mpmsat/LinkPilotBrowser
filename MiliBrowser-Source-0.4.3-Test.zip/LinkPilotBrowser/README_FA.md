# Mili Browser

مرورگر اندرویدی مبتنی بر Mozilla GeckoView با Mili Shield و Telegram Center داخلی.

## ویژگی‌های پایه نسخه 0.4.1 (GeckoView 150)

- موتور GeckoView، تب‌های lazy و حالت خصوصی
- نشانک، تاریخچه، دانلود مستقیم، اشتراک‌گذاری، Reader Mode و ترجمه متن انتخاب‌شده
- موتور جستجوی قابل انتخاب
- افزونه Mili Shield با فیلتر درخواست شبکه، تنظیمات عمومی و سایت‌محور، کنترل تصویر و فهرست مسدودی دستی
- Telegram Center مبتنی بر TDLib، ورود داخلی و تنظیم امن API ID/Hash
- فرمان‌های `/ql`، `/jl`، `/l` و `/yl` از منوی لمس طولانی لینک با حفظ دقیق پیشوند/پسوند

## اصلاحات نسخه 0.4.1

- تنظیمات سایت‌محور سه‌حالته (فعال/غیرفعال/پیروی از عمومی) و بازنشانی overrideها
- تفکیک استثناهای EasyList و EasyPrivacy و بهبود تشخیص درخواست‌های same-site
- اصلاح حالت تصویر تا لمس برای تصاویر `srcset` و `picture`

## ساخت

```bash
gradle --no-daemon :app:assembleDebug
```

جزئیات وضعیت واقعی، محدودیت‌ها و موارد آزمایش‌نشده در `DEVELOPMENT_STATUS_FA.md` آمده است. این سورس هنوز APK تأییدشده نیست.

## ساخت APK نسخه 0.4.2

پیش‌نیازها و محدودیت‌های تلگرام در `TELEGRAM_FEATURES_0.4.2_FA.md` آمده است. با JDK 17، Gradle 8.13 و Android SDK 36 در پوشه ریشه پروژه اجرا کنید:

```bash
bash BUILD_APK.sh
```

فایل APK در `app/build/outputs/apk/debug/app-debug.apk` ساخته می‌شود.
