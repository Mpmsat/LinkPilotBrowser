package com.milichrome.browser.feature.telegram

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import android.media.MediaRecorder
import android.os.Build
import android.content.Intent
import android.net.Uri
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Native in-app Telegram UI. It deliberately does not launch Telegram or load Telegram Web. */
class TelegramCenterActivity : Activity() {
    private val bg = Color.rgb(18, 20, 25)
    private val panel = Color.rgb(32, 36, 43)
    private val accent = Color.rgb(65, 145, 220)
    private val fg = Color.WHITE
    private var client: TelegramCenterContract? = null
    private var state = TelegramUiState()
    private lateinit var root: LinearLayout
    private var voiceRecorder: MediaRecorder? = null
    private var voiceFile: File? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val created = runCatching {
            TelegramCenterProvider.factory?.invoke() ?: TdlibCenterRuntime.get(applicationContext)
        }
        client = created.getOrNull()
        if (client == null) {
            showUnavailable(created.exceptionOrNull()?.message ?: "موتور TDLib در دسترس نیست")
            return
        }
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg) }
        setContentView(root)
        client?.observe { runOnUiThread { state = it; render() } }
        client?.loadChats()
        if (android.os.Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 772)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun label(value: String, size: Float = 15f, color: Int = fg) = TextView(this).apply {
        text = value; textSize = size; setTextColor(color); setPadding(dp(14), dp(10), dp(14), dp(10))
    }
    private fun action(value: String, callback: () -> Unit) = label(value, 15f, fg).apply {
        gravity = Gravity.CENTER; setBackgroundColor(panel); setOnClickListener { callback() }
    }
    private fun field(hintText: String, secret: Boolean = false) = EditText(this).apply {
        hint = hintText; setSingleLine(true); textSize = 16f; setTextColor(fg)
        setHintTextColor(Color.LTGRAY); setPadding(dp(14), dp(8), dp(14), dp(8)); setBackgroundColor(panel)
        if (secret) inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
    }

    private fun render() {
        root.removeAllViews()
        val header = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setBackgroundColor(panel) }
        header.addView(label("‹", 26f).apply { setOnClickListener { if (state.selectedChat != null) client?.showChatList() else finish() } })
        header.addView(label(state.selectedChat?.title ?: "Telegram داخلی", 18f).apply { layoutParams = LinearLayout.LayoutParams(0, -2, 1f) })
        if (state.authStep == TelegramAuthStep.READY) header.addView(label("مخاطبین").apply { setOnClickListener { client?.loadContacts { showContacts() } } })
        if (state.authStep == TelegramAuthStep.READY) header.addView(label("⋮").apply { setOnClickListener { showAccountMenu() } })
        root.addView(header)

        when (state.authStep) {
            TelegramAuthStep.PHONE, TelegramAuthStep.CODE, TelegramAuthStep.PASSWORD, TelegramAuthStep.ERROR -> renderAuth()
            TelegramAuthStep.READY -> if (state.selectedChat == null) renderChats() else renderConversation()
        }
    }

    private fun renderAuth() {
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(24), dp(20), dp(24), dp(20)) }
        body.addView(label("ورود امن به تلگرام", 22f, accent))
        body.addView(label(state.statusText.ifBlank { when (state.authStep) {
            TelegramAuthStep.PHONE -> "شماره تلفن را با کد کشور وارد کنید"
            TelegramAuthStep.CODE -> "کد ارسال‌شده از تلگرام را وارد کنید"
            TelegramAuthStep.PASSWORD -> "رمز تأیید دومرحله‌ای را وارد کنید"
            else -> "اطلاعات ورود را بررسی کنید"
        } }, 14f, Color.LTGRAY))
        val input = when (state.authStep) {
            TelegramAuthStep.PHONE, TelegramAuthStep.ERROR -> field("مثلاً +98912…")
            TelegramAuthStep.CODE -> field("کد تأیید")
            else -> field("رمز دومرحله‌ای", true)
        }
        input.imeOptions = EditorInfo.IME_ACTION_DONE
        body.addView(input, LinearLayout.LayoutParams(-1, dp(54)))
        body.addView(action("ادامه") {
            val value = input.text.toString()
            when (state.authStep) {
                TelegramAuthStep.PHONE, TelegramAuthStep.ERROR -> client?.requestPhone(value)
                TelegramAuthStep.CODE -> client?.submitCode(value)
                TelegramAuthStep.PASSWORD -> client?.submitPassword(value)
                else -> Unit
            }
        }, LinearLayout.LayoutParams(-1, dp(48)))
        root.addView(body, LinearLayout.LayoutParams(-1, 0, 1f))
    }

    private fun renderChats() {
        if (state.isLoading) root.addView(label("در حال دریافت گفتگوها…", 14f, Color.LTGRAY))
        val scroll = ScrollView(this)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        if (state.chats.isEmpty() && !state.isLoading) list.addView(label("گفتگویی برای نمایش وجود ندارد یا هنوز بارگیری نشده است."))
        state.chats.forEach { chat ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(4), dp(5), dp(4), dp(5)) }
            row.addView(label("${chat.title}  ·  ${chat.kind}", 16f))
            row.addView(label(chat.lastMessage, 13f, Color.LTGRAY))
            row.setOnClickListener { client?.openChat(chat.id) }
            list.addView(row)
            list.addView(View(this).apply { setBackgroundColor(Color.DKGRAY) }, LinearLayout.LayoutParams(-1, dp(1)))
        }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(action("گفتگوهای جدید / تازه‌سازی") { client?.loadChats() })
    }

    private fun renderConversation() {
        val chat = state.selectedChat ?: return
        val scroll = ScrollView(this)
        val messages = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(8), dp(8), dp(8)) }
        state.messages.forEach { message ->
            val bubble = label(message.text, 15f).apply {
                setBackgroundColor(if (message.outgoing) Color.rgb(35, 86, 75) else panel)
                maxWidth = (resources.displayMetrics.widthPixels * .82f).toInt()
            }
            val line = LinearLayout(this).apply { gravity = if (message.outgoing) Gravity.END else Gravity.START }
            line.addView(bubble)
            messages.addView(line)
            val time = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(message.timestamp * 1000))
            val receipt = if (message.outgoing) if (message.isRead) "  ✓✓" else "  ✓" else ""
            messages.addView(label(time + receipt, 10f, Color.LTGRAY))
            message.mediaPath?.let { path ->
                messages.addView(action("بازکردن پیوست: ${File(path).name}") {
                    val uri = androidx.core.content.FileProvider.getUriForFile(this, "$packageName.files", File(path))
                    val type = message.mediaMimeType ?: "*/*"
                    val view = Intent(Intent.ACTION_VIEW).setDataAndType(uri, type).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    runCatching { startActivity(Intent.createChooser(view, "بازکردن پیوست")) }
                        .onFailure { Toast.makeText(this, "برنامه‌ای برای بازکردن این فایل پیدا نشد", Toast.LENGTH_SHORT).show() }
                })
            }
        }
        scroll.addView(messages)
        root.addView(action("دریافت پیام‌های قدیمی‌تر") { client?.loadOlderMessages(chat.id) })
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val composer = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(6), dp(5), dp(6), dp(5)) }
        val text = field("پیام…")
        composer.addView(text, LinearLayout.LayoutParams(0, dp(50), 1f))
        composer.addView(action("＋") { openAttachmentPicker() })
        composer.addView(action(if (voiceRecorder == null) "🎙" else "■") { toggleVoiceRecording() })
        composer.addView(action("ارسال") {
            val value = text.text.toString()
            if (value.isNotEmpty()) { client?.sendText(chat.id, value); text.setText("") }
        })
        root.addView(composer)
    }

    private fun showAccountMenu() {
        AlertDialog.Builder(this).setItems(arrayOf("به‌روزرسانی گفتگوها", "مخاطبین", "تغییر API ID و API Hash", "خروج از حساب")) { _, which ->
            when (which) {
                0 -> client?.loadChats()
                1 -> { client?.loadContacts { showContacts() } }
                2 -> showApiCredentialsSetup()
                3 -> AlertDialog.Builder(this)
                    .setMessage("از حساب تلگرام خارج شوید؟")
                    .setNegativeButton("لغو", null)
                    .setPositiveButton("خروج") { _, _ -> client?.logout() }.show()
            }
        }.show()
    }


    private fun showContacts() {
        val contacts = state.contacts
        if (contacts.isEmpty()) {
            Toast.makeText(this, "مخاطبی دریافت نشد؛ کمی بعد دوباره امتحان کن", Toast.LENGTH_SHORT).show()
            return
        }
        val labels = contacts.map { if (it.username.isNotBlank()) "${it.name}  @${it.username}" else it.name }.toTypedArray()
        AlertDialog.Builder(this).setTitle("مخاطبین تلگرام").setItems(labels) { _, index -> client?.createPrivateChat(contacts[index].id) }.setNegativeButton("بستن", null).show()
    }

    private fun openAttachmentPicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }
        startActivityForResult(intent, 441)
    }

    @Deprecated("Deprecated by Android; retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 441 || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        val chatId = state.selectedChat?.id ?: return
        runCatching {
            val name = queryDisplayName(uri).ifBlank { "upload_${System.currentTimeMillis()}" }
            val safeName = name.replace(Regex("[^A-Za-z0-9._-]"), "_")
            val target = File(cacheDir, "telegram_uploads").apply { mkdirs() }.resolve(safeName)
            contentResolver.openInputStream(uri).use { input ->
                requireNotNull(input) { "فایل قابل خواندن نیست" }
                FileOutputStream(target).use { output -> input.copyTo(output) }
            }
            val mime = contentResolver.getType(uri) ?: "application/octet-stream"
            client?.sendMedia(chatId, target.absolutePath, mime)
            Toast.makeText(this, "ارسال فایل به تلگرام شروع شد", Toast.LENGTH_SHORT).show()
        }.onFailure { Toast.makeText(this, "خواندن فایل ناموفق بود: ${it.message}", Toast.LENGTH_LONG).show() }
    }

    private fun queryDisplayName(uri: Uri): String {
        val cursor = contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)
        cursor?.use { if (it.moveToFirst()) return it.getString(0).orEmpty() }
        return uri.lastPathSegment.orEmpty()
    }


    private fun toggleVoiceRecording() {
        if (voiceRecorder != null) {
            stopVoiceRecording()
            return
        }
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(android.Manifest.permission.RECORD_AUDIO), 773)
            return
        }
        startVoiceRecording()
    }

    private fun startVoiceRecording() {
        if (state.selectedChat == null) return
        val dir = File(cacheDir, "telegram_uploads").apply { mkdirs() }
        val isOpus = Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q
        val output = File(dir, "voice_${System.currentTimeMillis()}.${if (isOpus) "ogg" else "m4a"}")
        runCatching {
            val recorder = MediaRecorder()
            recorder.setAudioSource(MediaRecorder.AudioSource.MIC)
            if (isOpus) {
                recorder.setOutputFormat(MediaRecorder.OutputFormat.OGG)
                recorder.setAudioEncoder(MediaRecorder.AudioEncoder.OPUS)
            } else {
                recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            }
            recorder.setAudioSamplingRate(48000)
            recorder.setAudioEncodingBitRate(64000)
            recorder.setOutputFile(output.absolutePath)
            recorder.prepare()
            recorder.start()
            voiceRecorder = recorder
            voiceFile = output
            Toast.makeText(this, "ضبط پیام صوتی شروع شد؛ برای پایان دوباره 🎙 را بزن", Toast.LENGTH_LONG).show()
        }.onFailure {
            runCatching { voiceRecorder?.release() }
            voiceRecorder = null
            Toast.makeText(this, "شروع ضبط ممکن نشد: ${it.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun stopVoiceRecording() {
        val recorder = voiceRecorder ?: return
        val file = voiceFile
        voiceRecorder = null
        voiceFile = null
        runCatching { recorder.stop() }.onFailure {
            file?.delete()
            Toast.makeText(this, "ضبط خیلی کوتاه بود؛ فایل ساخته نشد", Toast.LENGTH_SHORT).show()
        }
        runCatching { recorder.reset(); recorder.release() }
        if (file?.isFile == true && file.length() > 0) {
            val mime = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) "audio/ogg" else "audio/mp4"
            state.selectedChat?.id?.let { client?.sendMedia(it, file.absolutePath, mime) }
            Toast.makeText(this, "ارسال پیام صوتی شروع شد", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 773 && grantResults.firstOrNull() == android.content.pm.PackageManager.PERMISSION_GRANTED) startVoiceRecording()
    }

    private fun showUnavailable(reason: String) {
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setBackgroundColor(bg); setPadding(dp(24), dp(24), dp(24), dp(24))
            addView(label("راه‌اندازی تلگرام انجام نشد", 20f, accent))
            addView(label(reason, 14f, Color.LTGRAY))
            addView(action("تنظیم API ID و API Hash تلگرام") { showApiCredentialsSetup() })
            addView(action("بازگشت") { finish() })
        })
    }


    private fun showApiCredentialsSetup() {
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(8), dp(18), dp(8)) }
        val apiId = field("API ID عددی")
        apiId.inputType = android.text.InputType.TYPE_CLASS_NUMBER
        val apiHash = field("API Hash", true)
        TelegramApiCredentialStore.load(this)?.let { saved ->
            apiId.setText(saved.apiId.toString())
            apiHash.setText(saved.apiHash)
        }
        body.addView(label("از my.telegram.org و بخش API development tools دریافت کن. این مقادیر روی همین گوشی رمزگذاری می‌شوند." , 13f, Color.LTGRAY))
        body.addView(apiId)
        body.addView(apiHash)
        AlertDialog.Builder(this).setTitle("اتصال تلگرام به Mili Browser").setView(body)
            .setPositiveButton("ذخیره و راه‌اندازی") { _, _ ->
                val id = apiId.text.toString().toIntOrNull()
                val hash = apiHash.text.toString()
                runCatching { TelegramApiCredentialStore.save(this, id ?: 0, hash) }
                    .onSuccess {
                        Toast.makeText(this, "اطلاعات به‌صورت رمزگذاری‌شده ذخیره شد؛ دوباره تلگرام داخلی را باز کن.", Toast.LENGTH_LONG).show()
                        finish()
                    }.onFailure { Toast.makeText(this, it.message ?: "ذخیره اطلاعات ناموفق بود", Toast.LENGTH_LONG).show() }
            }.setNegativeButton("لغو", null).show()
    }

    override fun onDestroy() {
        runCatching { voiceRecorder?.stop() }
        runCatching { voiceRecorder?.release() }
        voiceRecorder = null
        client?.close()
        super.onDestroy()
    }
}
