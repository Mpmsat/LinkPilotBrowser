# بسته کامل سورس و ساخت APK مرورگر Mili

## محتویات
- `Mili-Browser-Source.zip`: سورس کامل پروژه اندروید موجود در این بسته، با ساختار Gradle در ریشه آرشیو.
- `.github/workflows/android.yml`: گردش‌کار GitHub Actions برای ساخت APK دیباگ.
- `instructions/BUILD-ON-ANDROID-FA.txt`: راهنمای کامل انجام کار فقط با گوشی اندرویدی.

## روش استفاده
این بسته را در گوشی باز و از حالت فشرده خارج کنید. در مخزن GitHub خود:
1. فایل `Mili-Browser-Source.zip` را در ریشه مخزن بارگذاری کنید.
2. فایل `android.yml` را در مسیر `.github/workflows/android.yml` قرار دهید.
3. از زبانه Actions، گردش‌کار **Build Mili Browser APK** را اجرا کنید.
4. پس از موفقیت، از صفحه اجرای workflow بخش Artifacts، فایل APK را دریافت کنید.

## وضعیت واقعی این سورس
این بسته شامل پایه فعلی Mili بر مبنای GeckoView است، نه نسخه نهایی هم‌سطح Brave.
برخی ساختارها و مدل‌های اولیه در سورس وجود دارند، اما امکاناتی مانند اتصال واقعی TDLib برای تلگرام،
فیلتر کامل تبلیغات/ردیاب‌ها، مدیریت واقعی تصویر با تأخیر دانلود، ترجمه کامل، Reader Mode،
مدیریت رمز عبور و همگام‌سازی هنوز در این سورس تکمیل نشده‌اند.
ساخت موفق APK فقط کامپایل شدن همین سورس را ثابت می‌کند و به معنی تکمیل همه قابلیت‌ها یا تست روی گوشی نیست.

## مشخصات ساخت فعلی
- Application ID: `com.milichrome.browser`
- Engine: GeckoView
- minSdk: 26 (Android 8.0)
- targetSdk: 35
- compileSdk: 36
- ABI فعلی: `arm64-v8a`
- JDK: 17
- Gradle: 8.13
