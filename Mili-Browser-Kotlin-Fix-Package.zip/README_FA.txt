# Mili Browser — Kotlin compile fix

این بسته، سورس اصلی مرورگر را دوباره بسته‌بندی نمی‌کند؛ فایل‌های اصلاحی برای مخزن فعلی را دارد.
آرشیو سورس اصلی باید در ریشه مخزن باقی بماند:
- Mili-Browser-GeckoView-foundation.zip یا
- Mili-Browser-Full-Build-Kit.zip (به شرط داشتن Mili-Browser-Source.zip درون آن)

## نصب با گوشی
1. در GitHub مخزن LinkPilotBrowser را باز کنید.
2. فایل `.github/workflows/android.yml` را با فایل همین بسته جایگزین کنید.
3. Commit changes را بزنید.
4. به Actions بروید و workflow را اجرا کنید.
5. بعد از موفقیت، Artifact با نام `Mili-Browser-fixed-debug` را دانلود کنید.

## علت اصلاح
در `LegacyMainActivity.kt` ارجاع‌های `this@MainActivity` وجود داشت، در حالی که کلاس
فعالیت `LegacyMainActivity` است. workflow پیش از کامپایل، این برچسب‌ها را به
`this@LegacyMainActivity` تبدیل می‌کند.

این اصلاح فقط خطای کامپایل گزارش‌شده را هدف می‌گیرد و تضمین نمی‌کند که تمام قابلیت‌های
محصول نهایی Mili Browser تکمیل شده باشند.
