#!/usr/bin/env bash
set -euo pipefail
FILE="app/src/main/java/com/linkpilot/browser/LegacyMainActivity.kt"
test -f "$FILE" || { echo "Missing $FILE"; exit 1; }
sed -i 's/this@MainActivity/this@LegacyMainActivity/g' "$FILE"
if grep -n 'this@MainActivity' "$FILE"; then
  echo "Unfixed invalid activity labels remain"; exit 1
fi
echo "Kotlin activity labels fixed."
