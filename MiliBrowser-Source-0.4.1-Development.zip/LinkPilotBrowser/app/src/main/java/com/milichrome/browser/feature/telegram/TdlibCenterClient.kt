package com.milichrome.browser.feature.telegram

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import java.security.KeyStore
import java.io.File
import java.lang.reflect.Constructor
import java.lang.reflect.Proxy
import java.security.SecureRandom
import java.util.concurrent.CopyOnWriteArrayList

/** Real TDLib JNI adapter. TDLib's generated Java API is loaded from the checksum-pinned build bundle. */
class TdlibCenterClient(context: Context) : TelegramCenterContract {
    private val app = context.applicationContext
    private val main = Handler(Looper.getMainLooper())
    private val observers = CopyOnWriteArrayList<(TelegramUiState) -> Unit>()
    private val chats = linkedMapOf<Long, TelegramChat>()
    private val messages = linkedMapOf<Long, MutableList<TelegramMessage>>()
    private val apiCredentials = TelegramApiCredentialStore.load(app)
        ?: error("برای راه‌اندازی تلگرام، API ID و API Hash برنامه را در تنظیمات تلگرام وارد کن.")
    @Volatile private var state = TelegramUiState()
    @Volatile private var client: Any? = null
    val isAuthorized: Boolean get() = state.authStep == TelegramAuthStep.READY
    private val tdApi = "org.drinkless.tdlib.TdApi"
    private val clientApi = "org.drinkless.tdlib.Client"

    init {
        loadNativeLibraries()
        createClient()
    }

    private fun loadNativeLibraries() {
        System.loadLibrary("c++_shared")
        System.loadLibrary("cryptox")
        System.loadLibrary("sslx")
        System.loadLibrary("tdjni")
    }

    private fun createClient() {
        val clientClass = Class.forName(clientApi)
        val handlerClass = Class.forName("$clientApi\$ResultHandler")
        val callback = Proxy.newProxyInstance(handlerClass.classLoader, arrayOf(handlerClass)) { _, method, args ->
            if (method.name == "onResult" && !args.isNullOrEmpty()) handleTdObject(args[0])
            null
        }
        val create = clientClass.methods.first { it.name == "create" && it.parameterTypes.size == 3 }
        client = create.invoke(null, callback, null, null)
    }

    private fun send(function: Any, onResult: ((Any) -> Unit)? = null) {
        val target = client ?: return
        val functionClass = Class.forName("$tdApi\$Function")
        val handlerClass = Class.forName("$clientApi\$ResultHandler")
        val handler = Proxy.newProxyInstance(handlerClass.classLoader, arrayOf(handlerClass)) { _, method, args ->
            if (method.name == "onResult" && !args.isNullOrEmpty()) {
                val result = args[0]
                if (result.javaClass.simpleName == "Error") handleTdObject(result)
                else onResult?.invoke(result)
            }
            null
        }
        val method = target.javaClass.methods.first { it.name == "send" && it.parameterTypes.size == 2 && it.parameterTypes[0] == functionClass }
        method.invoke(target, function, handler)
    }

    private fun td(name: String, vararg args: Any?): Any {
        val type = Class.forName("$tdApi\$$name")
        fun compatible(parameter: Class<*>, value: Any?): Boolean {
            if (value == null) return !parameter.isPrimitive
            if (parameter.isInstance(value)) return true
            return when (parameter) {
                java.lang.Integer.TYPE -> value is Int
                java.lang.Long.TYPE -> value is Long
                java.lang.Boolean.TYPE -> value is Boolean
                java.lang.Double.TYPE -> value is Double
                java.lang.Float.TYPE -> value is Float
                java.lang.Short.TYPE -> value is Short
                java.lang.Byte.TYPE -> value is Byte
                java.lang.Character.TYPE -> value is Char
                else -> false
            }
        }
        val ctor: Constructor<*> = type.constructors.firstOrNull { constructor ->
            constructor.parameterTypes.size == args.size && constructor.parameterTypes.indices.all { i -> compatible(constructor.parameterTypes[i], args[i]) }
        } ?: error("TDLib API mismatch: compatible constructor $name(${args.size}) not found")
        return ctor.newInstance(*args)
    }

    private fun field(value: Any?, name: String): Any? = runCatching {
        value?.javaClass?.getField(name)?.get(value)
    }.getOrNull()

    private fun handleTdObject(value: Any) {
        when (value.javaClass.simpleName) {
            "UpdateAuthorizationState" -> handleAuthorization(field(value, "authorizationState") ?: return)
            "UpdateNewChat" -> {
                val chat = field(value, "chat") ?: return
                upsertChat(chat)
            }
            "UpdateChatTitle", "UpdateChatLastMessage", "UpdateChatUnreadMentionCount", "UpdateChatReadInbox" -> {
                val id = (field(value, "chatId") as? Number)?.toLong() ?: return
                requestChat(id)
            }
            "UpdateNewMessage" -> {
                val message = field(value, "message") ?: return
                upsertMessage(message)
            }
            "UpdateMessageContent" -> {
                val chatId = (field(value, "chatId") as? Number)?.toLong() ?: return
                val messageId = (field(value, "messageId") as? Number)?.toLong() ?: return
                val content = field(value, "newContent")
                val list = messages[chatId] ?: return
                val index = list.indexOfFirst { it.id == messageId }
                if (index >= 0) list[index] = list[index].copy(text = messageText(content))
                publish()
            }
            "Error" -> {
                val code = field(value, "code")
                val message = field(value, "message")?.toString().orEmpty()
                update { it.copy(isLoading = false, statusText = "خطای تلگرام ($code): $message") }
            }
        }
    }

    private fun handleAuthorization(auth: Any) {
        when (auth.javaClass.simpleName) {
            "AuthorizationStateWaitTdlibParameters" -> {
                val root = File(app.filesDir, "tdlib").apply { mkdirs() }
                val dbKey = databaseKey()
                val params = td(
                    "SetTdlibParameters",
                    false,
                    File(root, "database").apply { mkdirs() }.absolutePath,
                    File(root, "files").apply { mkdirs() }.absolutePath,
                    dbKey,
                    true, true, true, true,
                    apiCredentials.apiId,
                    apiCredentials.apiHash,
                    app.resources.configuration.locales[0].toLanguageTag(),
                    android.os.Build.MODEL ?: "Android",
                    android.os.Build.VERSION.RELEASE ?: "Android",
                    "Mili Browser 0.4.1"
                )
                send(params)
                update { it.copy(statusText = "در حال راه‌اندازی امن تلگرام…", isLoading = true) }
            }
            "AuthorizationStateWaitPhoneNumber" -> update { it.copy(authStep = TelegramAuthStep.PHONE, statusText = "شماره تلفن را با کد کشور وارد کنید", isLoading = false) }
            "AuthorizationStateWaitCode" -> update { it.copy(authStep = TelegramAuthStep.CODE, statusText = "کد تأیید ارسال‌شده را وارد کنید", isLoading = false) }
            "AuthorizationStateWaitPassword" -> update { it.copy(authStep = TelegramAuthStep.PASSWORD, statusText = "رمز تأیید دومرحله‌ای را وارد کنید", isLoading = false) }
            "AuthorizationStateReady" -> {
                update { it.copy(authStep = TelegramAuthStep.READY, statusText = "متصل شد", isLoading = false) }
                loadChats()
            }
            "AuthorizationStateLoggingOut" -> update { it.copy(statusText = "در حال خروج از حساب…", isLoading = true) }
            "AuthorizationStateClosing" -> update { it.copy(statusText = "در حال بستن نشست…", isLoading = true) }
            "AuthorizationStateClosed" -> {
                update { it.copy(authStep = TelegramAuthStep.PHONE, statusText = "نشست بسته شد؛ آمادهٔ ورود دوباره", isLoading = false) }
                main.post { runCatching { createClient() }.onFailure { error -> update { it.copy(statusText = error.message ?: "راه‌اندازی دوباره انجام نشد") } } }
            }
            else -> update { it.copy(statusText = "وضعیت ورود: ${auth.javaClass.simpleName}", isLoading = false) }
        }
    }

    private fun databaseKey(): ByteArray {
        val prefs = app.getSharedPreferences("tdlib_secure_bootstrap", Context.MODE_PRIVATE)
        val key = getOrCreateKeystoreKey()
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        val encrypted = prefs.getString("db_key_ciphertext", null)
        val iv = prefs.getString("db_key_iv", null)
        if (encrypted != null && iv != null) {
            cipher.init(Cipher.DECRYPT_MODE, key, javax.crypto.spec.GCMParameterSpec(128, Base64.decode(iv, Base64.NO_WRAP)))
            return cipher.doFinal(Base64.decode(encrypted, Base64.NO_WRAP))
        }
        val bytes = ByteArray(32).also { SecureRandom().nextBytes(it) }
        cipher.init(Cipher.ENCRYPT_MODE, key)
        val ciphertext = cipher.doFinal(bytes)
        prefs.edit()
            .putString("db_key_ciphertext", Base64.encodeToString(ciphertext, Base64.NO_WRAP))
            .putString("db_key_iv", Base64.encodeToString(cipher.iv, Base64.NO_WRAP))
            .commit()
        return bytes
    }

    private fun getOrCreateKeystoreKey(): SecretKey {
        val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        val alias = "mili_tdlib_database_key"
        (store.getKey(alias, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setRandomizedEncryptionRequired(true)
            .build())
        return generator.generateKey()
    }

    private fun upsertChat(raw: Any) {
        val id = (field(raw, "id") as? Number)?.toLong() ?: return
        val type = field(raw, "type")
        val bot = type?.javaClass?.simpleName == "ChatTypePrivate" && field(type, "userId") != null
        val chat = TelegramChat(
            id = id,
            title = field(raw, "title")?.toString().orEmpty().ifBlank { "گفتگو $id" },
            lastMessage = messageText(field(raw, "lastMessage")),
            unreadCount = (field(raw, "unreadCount") as? Number)?.toInt() ?: 0,
            isBot = bot
        )
        chats[id] = chat
        publish()
    }

    private fun requestChat(id: Long) {
        send(td("GetChat", id)) { result ->
            if (result.javaClass.simpleName == "Chat") upsertChat(result)
        }
    }

    private fun upsertMessage(raw: Any) {
        val chatId = (field(raw, "chatId") as? Number)?.toLong() ?: return
        val id = (field(raw, "id") as? Number)?.toLong() ?: return
        val timestamp = (field(raw, "date") as? Number)?.toLong() ?: 0L
        val outgoing = field(raw, "isOutgoing") as? Boolean ?: false
        val item = TelegramMessage(id, chatId, messageText(field(raw, "content")), outgoing, timestamp)
        val list = messages.getOrPut(chatId) { mutableListOf() }
        if (list.none { it.id == id }) list.add(item)
        list.sortBy { it.timestamp }
        publish()
    }

    private fun messageText(content: Any?): String {
        if (content == null) return ""
        return when (content.javaClass.simpleName) {
            "MessageText" -> field(field(content, "text"), "text")?.toString().orEmpty()
            "MessagePhoto" -> "📷 تصویر"
            "MessageVideo" -> "🎬 ویدئو"
            "MessageDocument" -> "📎 فایل"
            "MessageAudio" -> "🎵 فایل صوتی"
            "MessageVoiceNote" -> "🎤 پیام صوتی"
            "MessageSticker" -> "استیکر"
            "MessageAnimation" -> "GIF"
            else -> ""
        }
    }

    override fun observe(observer: (TelegramUiState) -> Unit) {
        observers += observer
        main.post { observer(state) }
    }

    override fun requestPhone(phoneNumber: String) {
        val value = phoneNumber.trim()
        if (!value.startsWith("+")) {
            update { it.copy(statusText = "شماره را همراه با کد کشور و علامت + وارد کنید") }
            return
        }
        update { it.copy(isLoading = true, statusText = "در حال درخواست کد تأیید…") }
        send(td("SetAuthenticationPhoneNumber", value, null))
    }

    override fun submitCode(code: String) {
        update { it.copy(isLoading = true, statusText = "در حال بررسی کد…") }
        send(td("CheckAuthenticationCode", code.trim()))
    }

    override fun submitPassword(password: String) {
        update { it.copy(isLoading = true, statusText = "در حال بررسی رمز دومرحله‌ای…") }
        send(td("CheckAuthenticationPassword", password))
    }

    override fun showChatList() {
        update { it.copy(selectedChat = null, messages = emptyList(), isLoading = false) }
        loadChats()
    }

    override fun loadChats() {
        update { it.copy(isLoading = true) }
        val list = td("ChatListMain")
        send(td("LoadChats", list, 100))
        main.postDelayed({ update { it.copy(chats = chats.values.sortedByDescending { c -> c.unreadCount.toLong() }, isLoading = false) } }, 1200)
    }

    override fun openChat(chatId: Long) {
        val selected = chats[chatId] ?: TelegramChat(chatId, "گفتگو $chatId")
        update { it.copy(selectedChat = selected, messages = messages[chatId].orEmpty(), isLoading = true) }
        send(td("GetChatHistory", chatId, 0L, 0, 50, false)) { result ->
            if (result.javaClass.simpleName == "Messages") {
                val array = field(result, "messages") as? Array<*> ?: emptyArray<Any>()
                array.filterNotNull().forEach(::upsertMessage)
            }
            update { it.copy(messages = messages[chatId].orEmpty(), isLoading = false) }
        }
    }

    override fun loadOlderMessages(chatId: Long) {
        val first = messages[chatId]?.minByOrNull { it.id }
        send(td("GetChatHistory", chatId, first?.id ?: 0L, 0, 50, false)) { result ->
            if (result.javaClass.simpleName == "Messages") {
                val array = field(result, "messages") as? Array<*> ?: emptyArray<Any>()
                array.filterNotNull().forEach(::upsertMessage)
            }
        }
    }

    override fun sendText(chatId: Long, text: String) {
        val entities = java.lang.reflect.Array.newInstance(Class.forName("$tdApi\$TextEntity"), 0)
        val formatted = td("FormattedText", text, entities)
        val content = td("InputMessageText", formatted, null, true)
        val request = td("SendMessage", chatId, null, null, null, null, content)
        send(request)
    }

    override fun sendTextToUsername(username: String, text: String) {
        val clean = username.removePrefix("@").trim()
        send(td("SearchPublicChat", clean)) { result ->
            if (result.javaClass.simpleName == "Chat") {
                val id = (field(result, "id") as? Number)?.toLong() ?: return@send
                sendText(id, text)
            } else {
                update { it.copy(statusText = "ربات یا کاربر @$clean پیدا نشد") }
            }
        }
    }

    override fun logout() { send(td("LogOut")) }

    override fun close() {
        // Keep the TDLib client alive across Activity recreation; the app process owns the session.
        observers.clear()
    }

    private fun update(transform: (TelegramUiState) -> TelegramUiState) {
        state = transform(state)
        publish()
    }

    private fun publish() {
        val snapshot = state.copy(
            chats = chats.values.sortedByDescending { it.unreadCount },
            messages = state.selectedChat?.let { messages[it.id].orEmpty().toList() } ?: state.messages
        )
        state = snapshot
        main.post { observers.forEach { observer -> runCatching { observer(snapshot) } } }
    }
}

/** Process-wide owner prevents duplicate TDLib databases when the Activity is recreated. */
object TdlibCenterRuntime {
    @Volatile private var instance: TdlibCenterClient? = null
    @Synchronized fun get(context: Context): TdlibCenterClient {
        return instance ?: TdlibCenterClient(context.applicationContext).also { instance = it }
    }
}
