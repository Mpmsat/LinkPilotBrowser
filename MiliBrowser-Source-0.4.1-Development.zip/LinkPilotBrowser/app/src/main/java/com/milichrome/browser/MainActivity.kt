package com.milichrome.browser

import android.app.Activity
import android.app.AlertDialog
import android.app.DownloadManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.ContentValues
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.Environment
import android.view.Gravity
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import android.provider.MediaStore
import com.linkpilot.browser.CommandStore
import com.linkpilot.browser.LinkCommand
import com.milichrome.browser.core.browser.BrowserDataStore
import com.milichrome.browser.core.browser.BrowserEngine
import com.milichrome.browser.core.tabs.BrowserTab
import com.milichrome.browser.core.browser.MiliShieldController
import com.milichrome.browser.feature.telegram.TdlibCenterRuntime
import com.milichrome.browser.feature.telegram.TelegramCenterActivity
import org.json.JSONObject
import org.mozilla.geckoview.GeckoSession
import org.mozilla.geckoview.GeckoSessionSettings
import org.mozilla.geckoview.GeckoResult
import org.mozilla.geckoview.AllowOrDeny
import org.mozilla.geckoview.GeckoView
import org.mozilla.geckoview.WebResponse
import java.io.File

class MainActivity : Activity() {
    private val black = Color.rgb(15, 15, 17)
    private val panel = Color.rgb(34, 34, 38)
    private val accent = Color.rgb(238, 91, 145)
    private val white = Color.WHITE
    private lateinit var engine: BrowserEngine
    private lateinit var shield: MiliShieldController
    private lateinit var data: BrowserDataStore
    private lateinit var host: FrameLayout
    private lateinit var address: EditText
    private lateinit var tabCount: TextView
    private var geckoView: GeckoView? = null
    private val tabs = mutableListOf<BrowserTab>()
    private var active = -1
    private val prefs by lazy { getSharedPreferences("mili_chrome_v2", Context.MODE_PRIVATE) }
    private val commandStore by lazy { CommandStore(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        engine = BrowserEngine(this)
        data = BrowserDataStore(this)
        shield = MiliShieldController(this, engine.runtime)
        buildUi()
        shield.install { ok, error ->
            if (ok) pushShieldSettings()
            else Toast.makeText(this, "Mili Shield راه‌اندازی نشد: ${error ?: "خطای ناشناخته"}", Toast.LENGTH_LONG).show()
        }
        val start = prefs.getString("home", "https://www.google.com") ?: "https://www.google.com"
        tabs += BrowserTab(url = start, title = "صفحه اصلی")
        activateTab(0)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun textButton(value: String, action: () -> Unit) = TextView(this).apply {
        text = value; textSize = 20f; gravity = Gravity.CENTER; setTextColor(white)
        setOnClickListener { action() }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(black) }
        host = FrameLayout(this).apply { setBackgroundColor(Color.WHITE) }
        root.addView(host, LinearLayout.LayoutParams(-1, 0, 1f))
        val bottom = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(black); setPadding(dp(7), dp(5), dp(7), dp(5)) }
        val addressRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        address = EditText(this).apply {
            hint = "جستجو یا نشانی وب"; setSingleLine(true); textSize = 14f
            setTextColor(white); setHintTextColor(Color.LTGRAY); setPadding(dp(12), 0, dp(8), 0)
            setBackgroundColor(panel); imeOptions = EditorInfo.IME_ACTION_GO
            setOnEditorActionListener { _, action, _ ->
                if (action == EditorInfo.IME_ACTION_GO) { navigate(text.toString()); clearFocus(); true } else false
            }
        }
        addressRow.addView(address, LinearLayout.LayoutParams(0, dp(44), 1f))
        addressRow.addView(textButton("↻") { currentSession()?.reload() }, LinearLayout.LayoutParams(dp(42), dp(44)))
        bottom.addView(addressRow)
        val tools = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(0, dp(3), 0, 0) }
        tools.addView(textButton("‹") { currentSession()?.goBack() }, LinearLayout.LayoutParams(0, dp(44), 1f))
        tools.addView(textButton("›") { currentSession()?.goForward() }, LinearLayout.LayoutParams(0, dp(44), 1f))
        tools.addView(textButton("⌂") { navigate(homeUrl()) }, LinearLayout.LayoutParams(0, dp(44), 1f))
        tools.addView(textButton("＋") { addTab(true) }, LinearLayout.LayoutParams(0, dp(44), 1f))
        tabCount = textButton("1") { showTabs() }
        tools.addView(tabCount, LinearLayout.LayoutParams(0, dp(44), 1f))
        tools.addView(textButton("⋮") { showMenu() }, LinearLayout.LayoutParams(0, dp(44), 1f))
        bottom.addView(tools)
        root.addView(bottom)
        setContentView(root)
        window.statusBarColor = black
        window.navigationBarColor = black
    }

    private fun homeUrl() = prefs.getString("home", "https://www.google.com") ?: "https://www.google.com"
    private fun currentTab() = tabs.getOrNull(active)
    private fun currentSession() = currentTab()?.session

    private fun normalize(raw: String): String {
        val value = raw.trim()
        if (value.isEmpty()) return "about:blank"
        if (value.startsWith("http://") || value.startsWith("https://") || value.startsWith("about:")) return value
        return if (value.contains('.') && !value.contains(' ')) "https://$value"
        else {
            val template = when (prefs.getString("search_engine", "google")) {
                "duckduckgo" -> "https://duckduckgo.com/?q={query}"
                "bing" -> "https://www.bing.com/search?q={query}"
                "brave" -> "https://search.brave.com/search?q={query}"
                else -> "https://www.google.com/search?q={query}"
            }
            template.replace("{query}", Uri.encode(value))
        }
    }

    private fun navigate(raw: String) {
        val tab = currentTab() ?: return
        var url = normalize(raw)
        if (prefs.getBoolean("https_upgrade", true) && url.startsWith("http://")) url = "https://" + url.removePrefix("http://")
        tab.url = url
        tab.hasStartedLoading = true
        address.setText(url)
        ensureSession(tab).loadUri(url)
        pushShieldSettings()
    }

    private fun ensureSession(tab: BrowserTab): GeckoSession {
        tab.session?.let { return it }
        val settings = GeckoSessionSettings.Builder()
            .usePrivateMode(tab.isPrivate)
            .useTrackingProtection(true)
            .build()
        val created = GeckoSession(settings)
        configureSession(created, tab)
        created.open(engine.runtime)
        tab.session = created
        return created
    }

    private fun configureSession(created: GeckoSession, tab: BrowserTab) {
        created.setNavigationDelegate(object : GeckoSession.NavigationDelegate {
            override fun onLocationChange(
                session: GeckoSession,
                url: String?,
                perms: MutableList<GeckoSession.PermissionDelegate.ContentPermission>,
                hasUserGesture: Boolean
            ) {
                val tabIndex = tabs.indexOfFirst { it.session === session }
                if (tabIndex >= 0 && !url.isNullOrBlank()) {
                    tabs[tabIndex].url = url
                    if (tabIndex == active) address.setText(url)
                    if (!tabs[tabIndex].isPrivate) data.addHistory(tabs[tabIndex].title, url)
                    if (tabIndex == active) pushShieldSettings()
                }
            }

            override fun onCanGoBack(session: GeckoSession, canGoBack: Boolean) {
                tabs.firstOrNull { it.session === session }?.canGoBack = canGoBack
            }

            override fun onCanGoForward(session: GeckoSession, canGoForward: Boolean) {
                tabs.firstOrNull { it.session === session }?.canGoForward = canGoForward
            }

            override fun onLoadRequest(session: GeckoSession, request: GeckoSession.NavigationDelegate.LoadRequest): GeckoResult<AllowOrDeny>? {
                if (request.target == GeckoSession.NavigationDelegate.TARGET_WINDOW_NEW && prefs.getBoolean("block_popups", true)) {
                    return GeckoResult.deny()
                }
                if (prefs.getBoolean("https_upgrade", true) && !request.isRedirect && request.uri.startsWith("http://")) {
                    val secureUrl = "https://" + request.uri.removePrefix("http://")
                    if (request.target == GeckoSession.NavigationDelegate.TARGET_WINDOW_NEW) addTab(true, secureUrl)
                    else session.loadUri(secureUrl)
                    return GeckoResult.deny()
                }
                return null
            }

            override fun onNewSession(session: GeckoSession, uri: String): GeckoResult<GeckoSession>? {
                if (prefs.getBoolean("block_popups", true)) return null
                val parent = tabs.firstOrNull { it.session === session }
                val newTab = BrowserTab(url = uri, title = "پنجره جدید", isPrivate = parent?.isPrivate ?: false)
                val newSettings = GeckoSessionSettings.Builder()
                    .usePrivateMode(newTab.isPrivate)
                    .useTrackingProtection(true)
                    .build()
                val newSession = GeckoSession(newSettings)
                configureSession(newSession, newTab)
                newTab.session = newSession
                newTab.hasStartedLoading = true // Gecko loads the requested URI after this callback.
                tabs.add(newTab)
                val newIndex = tabs.lastIndex
                updateTabCount()
                Handler(Looper.getMainLooper()).post { if (newIndex in tabs.indices) activateTab(newIndex) }
                return GeckoResult.fromValue(newSession)
            }
        })
        created.setContentDelegate(object : GeckoSession.ContentDelegate {
            override fun onTitleChange(session: GeckoSession, title: String?) {
                val tabIndex = tabs.indexOfFirst { it.session === session }
                if (tabIndex >= 0 && !title.isNullOrBlank()) {
                    tabs[tabIndex].title = title
                    if (tabIndex == active && tabs[tabIndex].url.startsWith("http")) {
                        if (!tabs[tabIndex].isPrivate) data.addHistory(title, tabs[tabIndex].url)
                    }
                }
            }
            override fun onContextMenu(session: GeckoSession, screenX: Int, screenY: Int, element: GeckoSession.ContentDelegate.ContextElement) {
                runOnUiThread { showLinkMenu(element.linkUri ?: element.srcUri, element.textContent ?: element.title ?: element.altText.orEmpty()) }
            }
            override fun onExternalResponse(session: GeckoSession, response: WebResponse) {
                saveExternalResponse(response)
            }
        })
        created.setSelectionActionDelegate(object : GeckoSession.SelectionActionDelegate {
            override fun onShowActionRequest(session: GeckoSession, selection: GeckoSession.SelectionActionDelegate.Selection) {
                val selectedText = selection.text
                if (selectedText.isBlank()) return
                AlertDialog.Builder(this@MainActivity).setTitle("متن انتخاب‌شده")
                    .setItems(arrayOf("کپی متن", "ترجمه به فارسی")) { _, which ->
                        when (which) {
                            0 -> { selection.copy(); Toast.makeText(this@MainActivity, "متن کپی شد", Toast.LENGTH_SHORT).show() }
                            1 -> { selection.hide(); translateText(selectedText) }
                        }
                    }.show()
            }
        })
    }

    private fun activateTab(index: Int) {
        if (index !in tabs.indices) return
        currentSession()?.setActive(false)
        geckoView?.releaseSession()
        active = index
        val tab = tabs[index]
        val session = ensureSession(tab)
        val newView = GeckoView(this)
        newView.setSession(session)
        geckoView = newView
        host.removeAllViews()
        host.addView(newView, FrameLayout.LayoutParams(-1, -1))
        session.setActive(true)
        if (!tab.hasStartedLoading && tab.url != "about:blank") {
            tab.hasStartedLoading = true
            session.loadUri(tab.url)
        }
        address.setText(if (tab.url == "about:blank") "" else tab.url)
        updateTabCount()
        pushShieldSettings()
    }

    private fun addTab(activateNow: Boolean, url: String = "about:blank", privateMode: Boolean = false) {
        tabs += BrowserTab(url = url, isPrivate = privateMode, title = if (privateMode) "تب خصوصی" else "تب جدید")
        if (activateNow) activateTab(tabs.lastIndex) else updateTabCount()
    }

    private fun updateTabCount() { if (::tabCount.isInitialized) tabCount.text = tabs.size.toString() }

    private fun showTabs() {
        val labels = tabs.mapIndexed { i, t -> "${if (i == active) "● " else ""}${if (t.isPrivate) "🔒 " else ""}${t.title}  ${t.url}" }.toTypedArray()
        AlertDialog.Builder(this).setTitle("تب‌ها")
            .setItems(labels) { _, which -> activateTab(which) }
            .setPositiveButton("تب عادی جدید") { _, _ -> addTab(true) }
            .setNeutralButton("تب خصوصی جدید") { _, _ -> addTab(true, privateMode = true) }
            .setNegativeButton("بستن تب فعلی") { _, _ -> closeTab() }.show()
    }

    private fun closeTab() {
        if (tabs.isEmpty()) return
        val closing = tabs.removeAt(active)
        closing.session?.close()
        if (tabs.isEmpty()) tabs += BrowserTab()
        activateTab(active.coerceAtMost(tabs.lastIndex))
    }

    private fun showMenu() {
        val items = arrayOf("نشانک‌ها", "تاریخچه", "افزودن نشانک", "دانلود صفحه فعلی", "حالت مطالعه", "اشتراک‌گذاری صفحه", "تنظیمات مرورگر و Mili Shield", "مدیریت فرمان‌های تلگرام", "آمار Mili Shield", "تلگرام داخلی", "تب خصوصی جدید", "خانه")
        AlertDialog.Builder(this).setTitle("Mili Browser").setItems(items) { _, which ->
            when (which) {
                0 -> showBookmarks()
                1 -> showHistory()
                2 -> addCurrentBookmark()
                3 -> downloadUrl(currentTab()?.url.orEmpty())
                4 -> openReaderMode()
                5 -> shareCurrentPage()
                6 -> showSettings()
                7 -> showCommandSettings()
                8 -> showShieldStats()
                9 -> startActivity(android.content.Intent(this, TelegramCenterActivity::class.java))
                10 -> addTab(true, privateMode = true)
                11 -> navigate(homeUrl())
            }
        }.show()
    }

    private fun addCurrentBookmark() {
        val tab = currentTab() ?: return
        if (data.addBookmark(tab.title, tab.url)) Toast.makeText(this, "نشانک ذخیره شد", Toast.LENGTH_SHORT).show()
        else Toast.makeText(this, "این صفحه قابل نشانک‌گذاری نیست", Toast.LENGTH_SHORT).show()
    }

    private fun showBookmarks() = showEntries("نشانک‌ها", data.bookmarks(), true)
    private fun showHistory() = showEntries("تاریخچه", data.history().asReversed(), false)
    private fun showEntries(title: String, entries: List<BrowserDataStore.Entry>, bookmark: Boolean) {
        if (entries.isEmpty()) { Toast.makeText(this, "موردی برای نمایش وجود ندارد", Toast.LENGTH_SHORT).show(); return }
        val labels = entries.map { "${it.title}\n${it.url}" }.toTypedArray()
        AlertDialog.Builder(this).setTitle(title).setItems(labels) { _, index -> navigate(entries[index].url) }
            .setNeutralButton(if (bookmark) "مدیریت نشانک‌ها" else "پاک‌کردن تاریخچه") { _, _ ->
                if (bookmark) showBookmarkManager() else AlertDialog.Builder(this).setMessage("تمام تاریخچه پاک شود؟")
                    .setNegativeButton("لغو", null).setPositiveButton("پاک کن") { _, _ -> data.clearHistory() }.show()
            }.show()
    }

    private fun showBookmarkManager() {
        val entries = data.bookmarks()
        if (entries.isEmpty()) return
        AlertDialog.Builder(this).setTitle("برای حذف نشانک انتخاب کن")
            .setItems(entries.map { it.title }.toTypedArray()) { _, which ->
                data.removeBookmark(entries[which].url)
                Toast.makeText(this, "نشانک حذف شد", Toast.LENGTH_SHORT).show()
                showBookmarkManager()
            }.show()
    }

    private fun showShieldStats() {
        shield.requestStats()
        Handler(Looper.getMainLooper()).postDelayed({
            val s = shield.lastStats
            val message = "تبلیغات: ${s.optInt("ads")}\nردیاب‌ها: ${s.optInt("trackers")}\nاسکریپت‌ها: ${s.optInt("scripts")}\nتصاویر: ${s.optInt("images")}\nدامنه‌های دستی: ${s.optInt("manual")}"
            AlertDialog.Builder(this).setTitle("آمار Mili Shield").setMessage(message).setPositiveButton("باشه", null).show()
        }, 350)
    }

    private fun openReaderMode() {
        val url = currentTab()?.url.orEmpty()
        if (!url.startsWith("http")) return
        addTab(true, "about:reader?url=${Uri.encode(url)}")
    }

    private fun shareCurrentPage() {
        val tab = currentTab() ?: return
        val share = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
            type = "text/plain"; putExtra(android.content.Intent.EXTRA_TEXT, tab.url); putExtra(android.content.Intent.EXTRA_SUBJECT, tab.title)
        }
        startActivity(android.content.Intent.createChooser(share, "اشتراک‌گذاری از Mili Browser"))
    }

    private fun showSettings() {
        val items = arrayOf("حالت تصاویر", "تنظیمات عمومی Mili Shield", "تنظیمات حفاظتی همین سایت", "مسدودسازی دستی دامنه", "مسدودسازی پنجره‌های بازشو", "ارتقای خودکار HTTP به HTTPS", "تغییر صفحه خانه", "انتخاب موتور جستجو")
        AlertDialog.Builder(this).setTitle("تنظیمات Mili Browser").setItems(items) { _, which ->
            when (which) {
                0 -> showImageModeSettings()
                1 -> showShieldSettings(false)
                2 -> showShieldSettings(true)
                3 -> addBlockedHost()
                4 -> togglePopupBlocking()
                5 -> { val enabled = !prefs.getBoolean("https_upgrade", true); prefs.edit().putBoolean("https_upgrade", enabled).apply(); Toast.makeText(this, if (enabled) "ارتقای HTTPS روشن شد" else "ارتقای HTTPS خاموش شد", Toast.LENGTH_SHORT).show() }
                6 -> editHome()
                7 -> chooseSearchEngine()
            }
        }.show()
    }

    private fun showImageModeSettings() {
        val labels = arrayOf("تصاویر عادی", "تصویر تار تا لمس (بارگذاری با لمس)", "بدون بارگذاری تصویر")
        val current = prefs.getInt("image_mode", 0).coerceIn(0, 2)
        AlertDialog.Builder(this).setTitle("کنترل تصاویر").setSingleChoiceItems(labels, current) { dialog, which ->
            prefs.edit().putInt("image_mode", which).apply(); pushShieldSettings(); currentSession()?.reload(); dialog.dismiss()
        }.setNegativeButton("بستن", null).show()
    }

    private fun showShieldSettings(siteOnly: Boolean) {
        val hostName = currentTab()?.url?.let { runCatching { Uri.parse(it).host }.getOrNull() }.orEmpty()
        if (siteOnly && hostName.isBlank()) { Toast.makeText(this, "ابتدا یک سایت باز کن", Toast.LENGTH_SHORT).show(); return }
        val keys = arrayOf("ads", "trackers", "scripts", "thirdPartyCookies", "fingerprint")
        val labels = arrayOf("مسدودسازی تبلیغات", "مسدودسازی ردیاب‌ها", "مسدودسازی اسکریپت‌ها", "محدودکردن کوکی‌های شخص ثالث", "محافظت ضداثر انگشت")
        val global = data.globalShield()
        if (siteOnly) {
            val overrides = data.siteShield(hostName)
            val choices = keys.indices.map { i ->
                val state = when {
                    !overrides.has(keys[i]) -> "پیروی از تنظیم عمومی"
                    overrides.optBoolean(keys[i]) -> "فعال (اختصاصی این سایت)"
                    else -> "غیرفعال (اختصاصی این سایت)"
                }
                "${labels[i]}  ·  $state"
            }.toTypedArray()
            AlertDialog.Builder(this).setTitle("حفاظت اختصاصی $hostName")
                .setItems(choices) { _, index ->
                    val key = keys[index]
                    val inherited = global.optBoolean(key, key != "scripts")
                    val current = when {
                        !overrides.has(key) -> 0
                        overrides.optBoolean(key) -> 1
                        else -> 2
                    }
                    AlertDialog.Builder(this).setTitle(labels[index])
                        .setSingleChoiceItems(arrayOf("پیروی از تنظیم عمومی (${if (inherited) "فعال" else "غیرفعال"})", "فعال", "غیرفعال"), current) { dialog, selected ->
                            when (selected) {
                                0 -> overrides.remove(key)
                                1 -> overrides.put(key, true)
                                2 -> overrides.put(key, false)
                            }
                            data.saveSiteShield(hostName, overrides)
                            pushShieldSettings(); currentSession()?.reload()
                            dialog.dismiss()
                            showShieldSettings(true)
                        }.setNegativeButton("لغو", null).show()
                }.setPositiveButton("پاک‌کردن همه استثناهای این سایت") { _, _ ->
                    data.saveSiteShield(hostName, JSONObject())
                    pushShieldSettings(); currentSession()?.reload()
                    Toast.makeText(this, "تنظیمات این سایت به حالت عمومی برگشت", Toast.LENGTH_SHORT).show()
                }.setNegativeButton("بستن", null).show()
            return
        }
        val checked = BooleanArray(keys.size) { i -> global.optBoolean(keys[i], i != 2) }
        AlertDialog.Builder(this).setTitle("Mili Shield عمومی")
            .setMultiChoiceItems(labels, checked) { _, which, value -> checked[which] = value }
            .setPositiveButton("ذخیره") { _, _ ->
                val result = JSONObject()
                keys.forEachIndexed { i, key -> result.put(key, checked[i]) }
                data.saveGlobalShield(result)
                pushShieldSettings(); currentSession()?.reload()
                Toast.makeText(this, "تنظیمات عمومی ذخیره شد", Toast.LENGTH_SHORT).show()
            }.setNegativeButton("لغو", null).show()
    }

    private fun pushShieldSettings() {
        if (!::shield.isInitialized || !::data.isInitialized) return
        val hostName = currentTab()?.url?.let { runCatching { Uri.parse(it).host }.getOrNull() }.orEmpty()
        val global = data.globalShield()
        val site = if (hostName.isNotBlank()) data.siteShield(hostName) else JSONObject()
        shield.pushSettings(global, site, hostName, data.blockedHosts(), prefs.getInt("image_mode", 0), prefs.getBoolean("block_popups", true))
    }

    private fun addBlockedHost() {
        val input = EditText(this).apply { hint = "مثلاً ads.example.com"; setSingleLine(true) }
        AlertDialog.Builder(this).setTitle("مسدودسازی دامنه").setView(input)
            .setPositiveButton("مسدود کن") { _, _ ->
                val hostName = input.text.toString().trim().lowercase().removePrefix("https://").removePrefix("http://").substringBefore('/')
                if (hostName.contains('.') && !hostName.contains(' ')) {
                    data.saveBlockedHosts(data.blockedHosts() + hostName); pushShieldSettings()
                    Toast.makeText(this, "$hostName به فهرست مسدودی اضافه شد", Toast.LENGTH_SHORT).show()
                }
            }.setNeutralButton("مدیریت فهرست") { _, _ -> manageBlockedHosts() }.setNegativeButton("لغو", null).show()
    }

    private fun manageBlockedHosts() {
        val hosts = data.blockedHosts().toList()
        if (hosts.isEmpty()) { Toast.makeText(this, "فهرست مسدودی خالی است", Toast.LENGTH_SHORT).show(); return }
        AlertDialog.Builder(this).setTitle("برای حذف دامنه انتخاب کن").setItems(hosts.toTypedArray()) { _, which ->
            data.saveBlockedHosts(data.blockedHosts() - hosts[which]); pushShieldSettings(); manageBlockedHosts()
        }.show()
    }

    private fun togglePopupBlocking() {
        val enabled = !prefs.getBoolean("block_popups", true)
        prefs.edit().putBoolean("block_popups", enabled).apply(); pushShieldSettings()
        Toast.makeText(this, if (enabled) "مسدودسازی پنجره‌های بازشو روشن شد" else "مسدودسازی پنجره‌های بازشو خاموش شد", Toast.LENGTH_SHORT).show()
    }


    private fun chooseSearchEngine() {
        val keys = arrayOf("google", "duckduckgo", "bing", "brave")
        val labels = arrayOf("Google", "DuckDuckGo", "Bing", "Brave Search")
        val current = keys.indexOf(prefs.getString("search_engine", "google")).coerceAtLeast(0)
        AlertDialog.Builder(this).setTitle("موتور جستجو").setSingleChoiceItems(labels, current) { dialog, which ->
            prefs.edit().putString("search_engine", keys[which]).apply(); dialog.dismiss()
        }.setNegativeButton("بستن", null).show()
    }

    private fun editHome() {
        val input = EditText(this).apply { setSingleLine(true); hint = "https://example.com"; setText(homeUrl()) }
        AlertDialog.Builder(this).setTitle("صفحه خانه").setView(input)
            .setPositiveButton("ذخیره") { _, _ -> prefs.edit().putString("home", normalize(input.text.toString())).apply() }
            .setNegativeButton("لغو", null).show()
    }

    private fun showCommandSettings() {
        val commands = commandStore.all()
        val labels = commands.map { "${if (it.enabled) "●" else "○"} ${it.title}  (${it.prefix}{LINK}${it.suffix})" }.toTypedArray()
        AlertDialog.Builder(this).setTitle("فرمان‌های ارسال لینک").setItems(labels) { _, which -> editCommand(commands[which]) }
            .setPositiveButton("بازنشانی پیش‌فرض") { _, _ -> commandStore.save(listOf(
                LinkCommand("ql", "ارسال با /ql", "/ql ", ""), LinkCommand("jl", "ارسال با /jl", "/jl ", ""),
                LinkCommand("l", "ارسال با /l", "/l ", ""), LinkCommand("yl", "ارسال با /yl", "/yl ", "")
            )) }.setNegativeButton("بستن", null).show()
    }

    private fun editCommand(existing: LinkCommand) {
        val prefix = EditText(this).apply { hint = "پیشوند دقیق؛ فاصله و خط جدید حفظ می‌شود"; setText(existing.prefix); minLines = 2; gravity = Gravity.TOP }
        val suffix = EditText(this).apply { hint = "پسوند دقیق؛ فاصله و خط جدید حفظ می‌شود"; setText(existing.suffix); minLines = 2; gravity = Gravity.TOP }
        val bot = EditText(this).apply { hint = "@V2TGbot"; setText(existing.bot); setSingleLine(true) }
        val enabled = android.widget.CheckBox(this).apply { text = "فعال"; setTextColor(white); isChecked = existing.enabled }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(8), dp(18), dp(8)); addView(prefix); addView(suffix); addView(bot); addView(enabled) }
        AlertDialog.Builder(this).setTitle(existing.title).setView(box)
            .setPositiveButton("ذخیره") { _, _ ->
                val updated = existing.copy(prefix = prefix.text.toString(), suffix = suffix.text.toString(), bot = bot.text.toString(), enabled = enabled.isChecked)
                commandStore.save(commandStore.all().map { if (it.id == existing.id) updated else it })
            }.setNegativeButton("لغو", null).show()
    }

    private fun showLinkMenu(url: String?, linkText: String) {
        if (url.isNullOrBlank()) return
        val commands = commandStore.all().filter { it.enabled }
        val labels = mutableListOf("بازکردن در تب جدید", "کپی لینک", "ترجمه عنوان/متن لینک", "دانلود لینک", "مسدودسازی دامنه")
        commands.forEach { labels += it.title }
        AlertDialog.Builder(this).setTitle(linkText.ifBlank { url }).setItems(labels.toTypedArray()) { _, which ->
            when (which) {
                0 -> addTab(true, url)
                1 -> copyText(url)
                2 -> translateText(linkText.ifBlank { url })
                3 -> downloadUrl(url)
                4 -> blockHostFromUrl(url)
                else -> sendCommand(commands[which - 5], url)
            }
        }.show()
    }

    private fun sendCommand(command: LinkCommand, url: String) {
        val message = command.render(url) // Do not trim: preserve prefix/suffix byte-for-byte.
        runCatching { TdlibCenterRuntime.get(applicationContext) }
            .onSuccess { telegram ->
                if (!telegram.isAuthorized) {
                    Toast.makeText(this, "ابتدا وارد حساب تلگرام داخلی شو و دوباره فرمان را اجرا کن", Toast.LENGTH_LONG).show()
                    startActivity(android.content.Intent(this, TelegramCenterActivity::class.java))
                } else {
                    telegram.sendTextToUsername(command.bot, message)
                    Toast.makeText(this, "درخواست ارسال به ${command.bot} ثبت شد؛ وضعیت را در تلگرام بررسی کن", Toast.LENGTH_LONG).show()
                }
            }.onFailure { error ->
                AlertDialog.Builder(this).setTitle("تلگرام آماده نیست")
                    .setMessage("برای ارسال مستقیم، ابتدا Telegram Center را راه‌اندازی کن.\n${error.message ?: ""}")
                    .setPositiveButton("بازکردن تلگرام داخلی") { _, _ -> startActivity(android.content.Intent(this, TelegramCenterActivity::class.java)) }
                    .setNegativeButton("بستن", null).show()
            }
    }

    private fun copyText(value: String) {
        getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("Mili Browser", value))
        Toast.makeText(this, "کپی شد", Toast.LENGTH_SHORT).show()
    }

    private fun translateText(value: String) {
        val url = "https://translate.google.com/?sl=auto&tl=fa&text=${Uri.encode(value)}&op=translate"
        addTab(true, url)
    }

    private fun blockHostFromUrl(url: String) {
        val hostName = runCatching { Uri.parse(url).host }.getOrNull().orEmpty()
        if (hostName.isNotBlank()) {
            data.saveBlockedHosts(data.blockedHosts() + hostName); pushShieldSettings()
            Toast.makeText(this, "$hostName مسدود شد", Toast.LENGTH_SHORT).show()
        }
    }

    private fun saveExternalResponse(response: WebResponse) {
        val input = response.body ?: run { downloadUrl(response.uri); return }
        val mime = response.headers["content-type"]?.substringBefore(';') ?: "application/octet-stream"
        val disposition = response.headers["content-disposition"].orEmpty()
        val fromHeader = Regex("""filename\*?=(?:UTF-8''|")?([^";]+)""", RegexOption.IGNORE_CASE)
            .find(disposition)?.groupValues?.getOrNull(1)?.trim()
        val rawName = fromHeader?.takeIf { it.isNotBlank() } ?: Uri.parse(response.uri).lastPathSegment ?: "mili-download"
        val filename = rawName.substringAfterLast('/').replace(Regex("""[\\/:*?"<>|]"""), "_").take(120).ifBlank { "mili-download" }
        Thread {
            runCatching {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    val values = ContentValues().apply {
                        put(MediaStore.MediaColumns.DISPLAY_NAME, filename)
                        put(MediaStore.MediaColumns.MIME_TYPE, mime)
                        put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                        put(MediaStore.MediaColumns.IS_PENDING, 1)
                    }
                    val target = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                        ?: error("ساخت فایل دانلود ناموفق بود")
                    contentResolver.openOutputStream(target)?.use { output -> input.use { it.copyTo(output) } }
                        ?: error("بازکردن فایل مقصد ناموفق بود")
                    contentResolver.update(target, ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }, null, null)
                } else {
                    val directory = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: cacheDir
                    directory.mkdirs()
                    File(directory, filename).outputStream().use { output -> input.use { it.copyTo(output) } }
                }
            }.onSuccess {
                runOnUiThread { Toast.makeText(this, "دانلود $filename کامل شد", Toast.LENGTH_LONG).show() }
            }.onFailure { error ->
                runCatching { input.close() }
                runOnUiThread { Toast.makeText(this, "دانلود ناموفق بود: ${error.message}", Toast.LENGTH_LONG).show() }
            }
        }.start()
    }

    private fun downloadUrl(url: String) {
        if (!url.startsWith("http://") && !url.startsWith("https://")) return
        runCatching {
            val filename = (Uri.parse(url).lastPathSegment ?: "mili-download").replace(Regex("""[\\/:*?"<>|]"""), "_").take(120)
            val request = DownloadManager.Request(Uri.parse(url))
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setAllowedOverMetered(true).setAllowedOverRoaming(false)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, filename)
            else request.setDestinationInExternalFilesDir(this, Environment.DIRECTORY_DOWNLOADS, filename)
            getSystemService(DownloadManager::class.java).enqueue(request)
        }.onSuccess { Toast.makeText(this, "دانلود به صف سیستم اضافه شد", Toast.LENGTH_SHORT).show() }
            .onFailure { Toast.makeText(this, "شروع دانلود ناموفق بود: ${it.message}", Toast.LENGTH_LONG).show() }
    }

    @Deprecated("Deprecated in Android")
    override fun onBackPressed() {
        val tab = currentTab()
        when {
            tab?.canGoBack == true -> currentSession()?.goBack()
            tabs.size > 1 -> closeTab()
            else -> super.onBackPressed()
        }
    }

    override fun onPause() { currentSession()?.setActive(false); super.onPause() }
    override fun onResume() { super.onResume(); currentSession()?.setActive(true); pushShieldSettings() }
    override fun onDestroy() { tabs.forEach { it.session?.close() }; super.onDestroy() }
}
