package com.milichrome.browser.core.browser

import android.content.Context
import android.util.Log
import org.json.JSONObject
import org.mozilla.geckoview.GeckoRuntime
import org.mozilla.geckoview.WebExtension
import java.util.concurrent.atomic.AtomicBoolean

/** Installs Mili Shield and keeps a native messaging channel to its request filter. */
class MiliShieldController(context: Context, private val runtime: GeckoRuntime) {
    private val installed = AtomicBoolean(false)
    @Volatile private var extension: WebExtension? = null
    @Volatile private var port: WebExtension.Port? = null
    @Volatile var lastStats: JSONObject = JSONObject()
        private set
    private val pending = mutableListOf<JSONObject>()

    fun install(onReady: ((Boolean, String?) -> Unit)? = null) {
        if (installed.get()) { onReady?.invoke(true, null); return }
        runtime.webExtensionController.ensureBuiltIn(
            "resource://android/assets/extensions/mili-shield/",
            "mili-shield@milichrome.local"
        ).accept({ ext ->
            runtime.webExtensionController.setAllowedInPrivateBrowsing(ext, true).accept({ privateReady ->
                attachExtension(privateReady, onReady)
            }, { privateError ->
                Log.w("MiliShield", "Private browsing permission could not be applied", privateError)
                attachExtension(ext, onReady)
            })
        }, { error ->
            Log.e("MiliShield", "Could not install built-in Shield", error)
            onReady?.invoke(false, error.message)
        })
    }


    private fun attachExtension(ext: WebExtension, onReady: ((Boolean, String?) -> Unit)?) {
        extension = ext
        ext.setMessageDelegate(object : WebExtension.MessageDelegate {
            override fun onConnect(port: WebExtension.Port) {
                this@MiliShieldController.port = port
                port.setDelegate(object : WebExtension.PortDelegate {
                    override fun onPortMessage(message: Any, port: WebExtension.Port) {
                        if (message is JSONObject && message.optString("type") == "mili:stats") lastStats = message
                        Log.d("MiliShield", "Extension event: $message")
                    }
                    override fun onDisconnect(port: WebExtension.Port) {
                        if (this@MiliShieldController.port === port) this@MiliShieldController.port = null
                    }
                })
                synchronized(pending) {
                    pending.forEach { port.postMessage(it) }
                    pending.clear()
                }
            }
        }, "mili")
        installed.set(true)
        onReady?.invoke(true, null)
    }

    fun requestStats() = sendMessage(JSONObject().put("type", "mili:get-stats"))

    private fun sendMessage(payload: JSONObject) {
        val activePort = port
        if (activePort != null) runCatching { activePort.postMessage(payload) }
        else synchronized(pending) { pending.add(payload) }
    }

    fun pushSettings(global: JSONObject, site: JSONObject?, host: String?, blockedHosts: Set<String>, imageMode: Int, blockPopups: Boolean) {
        val payload = JSONObject().apply {
            put("type", "mili:configure")
            put("global", global)
            put("site", site ?: JSONObject())
            put("host", host ?: "")
            put("blockedHosts", org.json.JSONArray(blockedHosts.toList()))
            put("imageMode", imageMode)
            put("blockPopups", blockPopups)
        }
        sendMessage(payload)
    }
}
