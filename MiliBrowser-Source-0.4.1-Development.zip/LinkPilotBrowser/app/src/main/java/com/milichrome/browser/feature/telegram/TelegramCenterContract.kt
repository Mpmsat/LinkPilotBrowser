package com.milichrome.browser.feature.telegram

/** UI/backend boundary. The production implementation must be backed by TDLib JNI. */
interface TelegramCenterContract {
    fun observe(observer: (TelegramUiState) -> Unit)
    fun requestPhone(phoneNumber: String)
    fun submitCode(code: String)
    fun submitPassword(password: String)
    fun loadChats()
    fun showChatList()
    fun openChat(chatId: Long)
    fun loadOlderMessages(chatId: Long)
    fun sendText(chatId: Long, text: String)
    fun sendTextToUsername(username: String, text: String)
    fun logout()
    fun close()
}

data class TelegramChat(
    val id: Long,
    val title: String,
    val lastMessage: String = "",
    val unreadCount: Int = 0,
    val isBot: Boolean = false
)

data class TelegramMessage(
    val id: Long,
    val chatId: Long,
    val text: String,
    val outgoing: Boolean,
    val timestamp: Long
)

enum class TelegramAuthStep { PHONE, CODE, PASSWORD, READY, ERROR }

data class TelegramUiState(
    val authStep: TelegramAuthStep = TelegramAuthStep.PHONE,
    val statusText: String = "",
    val chats: List<TelegramChat> = emptyList(),
    val selectedChat: TelegramChat? = null,
    val messages: List<TelegramMessage> = emptyList(),
    val isLoading: Boolean = false
)

/** Install the TDLib-backed implementation here during app composition. */
object TelegramCenterProvider {
    @Volatile var factory: (() -> TelegramCenterContract)? = null
}
