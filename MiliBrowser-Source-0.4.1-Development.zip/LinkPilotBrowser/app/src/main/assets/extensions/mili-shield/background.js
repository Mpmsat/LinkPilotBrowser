/* Mili Shield: request interception happens before the resource is fetched. */
const DEFAULTS = {
  global: { ads: true, trackers: true, scripts: false, thirdPartyCookies: true, fingerprint: true },
  sites: {},
  manualBlockedHosts: [],
  imageMode: 0,
  blockPopups: true
};
const AD_HOSTS = ["doubleclick.net", "googlesyndication.com", "googleadservices.com", "adservice.google.com", "adnxs.com", "adform.net", "taboola.com", "outbrain.com", "scorecardresearch.com"];
const TRACKER_HOSTS = ["google-analytics.com", "googletagmanager.com", "facebook.net", "connect.facebook.net", "hotjar.com", "segment.io", "mixpanel.com", "clarity.ms"];
const FINGERPRINT_HOSTS = ["fingerprintjs.com", "fpjs.io", "cdn.jsdelivr.net/npm/@fingerprintjs", "client-api.arkoselabs.com"];
const AD_TYPES = new Set(["image", "sub_frame", "xmlhttprequest", "script", "font", "stylesheet", "media"]);
let settings = structuredClone(DEFAULTS);
let stats = { ads: 0, trackers: 0, scripts: 0, images: 0, manual: 0 };
let easyListHosts = new Set();
let privacyListHosts = new Set();
let easyAllowHosts = new Set();
let privacyAllowHosts = new Set();
const allowImageOnce = new Set();
const hostOf = value => { try { return new URL(value).hostname.toLowerCase(); } catch (_) { return ""; } };
const matches = (host, rule) => host === rule || host.endsWith("." + rule);
function inDomainSet(host, set) { let current = host; while (current) { if (set.has(current)) return true; const dot = current.indexOf("."); if (dot < 0) break; current = current.slice(dot + 1); } return false; }
const sitePrefs = documentHost => ({ ...settings.global, ...(settings.sites[hostOf(documentHost)] || {}) });
const MULTI_LABEL_SUFFIXES = new Set(["co.uk", "org.uk", "ac.uk", "com.au", "net.au", "org.au", "co.jp", "co.nz", "com.br", "com.cn", "com.tr", "co.in"]);
function siteKey(host) {
  const labels = host.split(".").filter(Boolean);
  if (labels.length < 2) return host;
  const suffix2 = labels.slice(-2).join(".");
  return labels.slice(MULTI_LABEL_SUFFIXES.has(suffix2) ? -3 : -2).join(".");
}
const isThirdParty = (details) => {
  const target = hostOf(details.url), origin = hostOf(details.originUrl || details.documentUrl || "");
  return !!target && !!origin && siteKey(target) !== siteKey(origin);
};
function extractHostRules(text, allow = false) {
  const result = new Set();
  for (const raw of text.split(/\r?\n/)) {
    let line = raw.trim();
    if (!line || line.startsWith("!") || line.startsWith("[") || line.includes("##") || line.includes("#@#")) continue;
    if (line.startsWith("@@")) { if (!allow) continue; line = line.slice(2); }
    else if (allow) continue;
    if (!line.startsWith("||") || line.includes("$")) continue;
    let host = line.slice(2).split(/[\^/*|]/, 1)[0].toLowerCase();
    if (host.startsWith("www.")) host = host.slice(4);
    if (host.includes(".") && /^[a-z0-9.-]+$/.test(host)) result.add(host);
  }
  return result;
}
async function refreshFilterLists() {
  const saved = await browser.storage.local.get(["easyListHosts", "privacyListHosts", "easyAllowHosts", "privacyAllowHosts", "filterUpdatedAt"]);
  easyListHosts = new Set(saved.easyListHosts || []);
  privacyListHosts = new Set(saved.privacyListHosts || []);
  easyAllowHosts = new Set(saved.easyAllowHosts || []);
  privacyAllowHosts = new Set(saved.privacyAllowHosts || []);
  if (Date.now() - (saved.filterUpdatedAt || 0) < 7 * 24 * 60 * 60 * 1000) return;
  try {
    const [ads, privacy] = await Promise.all([
      fetch("https://easylist.to/easylist/easylist.txt", { cache: "no-store" }).then(r => { if (!r.ok) throw new Error("EasyList HTTP " + r.status); return r.text(); }),
      fetch("https://easylist.to/easylist/easyprivacy.txt", { cache: "no-store" }).then(r => { if (!r.ok) throw new Error("EasyPrivacy HTTP " + r.status); return r.text(); })
    ]);
    easyListHosts = extractHostRules(ads);
    privacyListHosts = extractHostRules(privacy);
    easyAllowHosts = extractHostRules(ads, true);
    privacyAllowHosts = extractHostRules(privacy, true);
    await browser.storage.local.set({ easyListHosts: [...easyListHosts], privacyListHosts: [...privacyListHosts], easyAllowHosts: [...easyAllowHosts], privacyAllowHosts: [...privacyAllowHosts], filterUpdatedAt: Date.now() });
  } catch (error) { console.warn("Mili Shield filter list update failed; using cached/basic rules", error); }
}
function shouldBlock(details) {
  const host = hostOf(details.url);
  if (!host) return false;
  const doc = details.documentUrl || details.originUrl || details.url;
  const prefs = sitePrefs(doc);
  if (settings.manualBlockedHosts.some(rule => matches(host, rule))) { stats.manual++; return true; }
  const adsAllowed = inDomainSet(host, easyAllowHosts);
  const trackersAllowed = inDomainSet(host, privacyAllowHosts);
  if (prefs.ads && !adsAllowed && AD_TYPES.has(details.type) && (AD_HOSTS.some(rule => matches(host, rule)) || inDomainSet(host, easyListHosts))) { stats.ads++; return true; }
  if (prefs.trackers && !trackersAllowed && (TRACKER_HOSTS.some(rule => matches(host, rule)) || inDomainSet(host, privacyListHosts))) { stats.trackers++; return true; }
  if (prefs.fingerprint && FINGERPRINT_HOSTS.some(rule => host.includes(rule))) { stats.trackers++; return true; }
  if (prefs.scripts && details.type === "script") { stats.scripts++; return true; }
  if (details.type === "image" && settings.imageMode === 2) { stats.images++; return true; }
  if (details.type === "image" && settings.imageMode === 1 && allowImageOnce.has(details.url)) { allowImageOnce.delete(details.url); return false; }
  if (details.type === "image" && settings.imageMode === 1) { stats.images++; return true; }
  return false;
}

const settingsReady = browser.storage.local.get(DEFAULTS).then(saved => {
  settings = { ...DEFAULTS, ...(saved || {}) };
});
settingsReady.then(() => refreshFilterLists());
browser.alarms.create("mili-filter-refresh", { periodInMinutes: 60 * 24 * 7 });
browser.alarms.onAlarm.addListener(alarm => { if (alarm.name === "mili-filter-refresh") refreshFilterLists(); });
browser.webRequest.onBeforeRequest.addListener(details => shouldBlock(details) ? { cancel: true } : {}, { urls: ["<all_urls>"] }, ["blocking"]);
browser.webRequest.onBeforeSendHeaders.addListener(details => {
  const prefs = sitePrefs(details.documentUrl || details.originUrl || "");
  if (prefs.thirdPartyCookies && isThirdParty(details)) {
    details.requestHeaders = (details.requestHeaders || []).filter(h => !["cookie", "cookie2"].includes(h.name.toLowerCase()));
  }
  return { requestHeaders: details.requestHeaders };
}, { urls: ["<all_urls>"] }, ["blocking", "requestHeaders"]);
browser.webRequest.onHeadersReceived.addListener(details => {
  const prefs = sitePrefs(details.documentUrl || details.originUrl || "");
  if (prefs.thirdPartyCookies && isThirdParty(details)) {
    details.responseHeaders = (details.responseHeaders || []).filter(h => !["set-cookie", "set-cookie2"].includes(h.name.toLowerCase()));
  }
  return { responseHeaders: details.responseHeaders };
}, { urls: ["<all_urls>"] }, ["blocking", "responseHeaders"]);

const nativePort = browser.runtime.connectNative("mili");
nativePort.onMessage.addListener(async message => {
  if (!message || typeof message !== "object") return;
  await settingsReady;
  if (message.type === "mili:configure") {
    settings.global = { ...settings.global, ...(message.global || {}) };
    if (message.host) settings.sites[message.host] = { ...(message.site || {}) };
    if (Array.isArray(message.blockedHosts)) settings.manualBlockedHosts = message.blockedHosts.filter(x => typeof x === "string");
    if (Number.isInteger(message.imageMode)) settings.imageMode = Math.max(0, Math.min(2, message.imageMode));
    settings.blockPopups = !!message.blockPopups;
    await browser.storage.local.set(settings);
    nativePort.postMessage({ type: "mili:settings-applied", ok: true });
  } else if (message.type === "mili:allow-image" && typeof message.url === "string") {
    allowImageOnce.add(message.url);
  } else if (message.type === "mili:get-stats") {
    nativePort.postMessage({ type: "mili:stats", ...stats });
  }
});

browser.runtime.onMessage.addListener(message => {
  if (message?.type === "mili:get-settings") return Promise.resolve({ imageMode: settings.imageMode, blockPopups: settings.blockPopups });
  if (message?.type === "mili:allow-image" && typeof message.url === "string") {
    allowImageOnce.add(message.url);
    return Promise.resolve({ ok: true });
  }
  return undefined;
});
